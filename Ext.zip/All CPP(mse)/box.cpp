#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <iomanip>
#include <cmath>

using namespace std;

// Split CSV line
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        result.push_back(token);
    }
    return result;
}

// Read CSV
bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (first) {
            headers = parts;
            first = false;
        } else if (!parts.empty()) {
            rows.push_back(parts);
        }
    }

    if (headers.empty() || rows.empty()) {
        cerr << "❌ Error: Empty or invalid CSV file.\n";
        return false;
    }

    cout << "\n✅ File loaded successfully!\n";
    cout << "Available columns: ";
    for (auto& h : headers) cout << h << "  ";
    cout << "\n";
    return true;
}

// Percentile
double percentile(const vector<double>& data, double percent) {
    if (data.empty()) return NAN;
    double rank = (percent / 100.0) * (data.size() - 1);
    int low = floor(rank);
    int high = ceil(rank);
    if (low == high) return data[low];
    return data[low] + (data[high] - data[low]) * (rank - low);
}

// Five-number summary
void fiveNumberSummary(const string& filename, const string& column) {
    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(filename, headers, rows)) return;

    // Find column
    int colIdx = find(headers.begin(), headers.end(), column) - headers.begin();
    if (colIdx >= headers.size()) {
        cerr << "❌ Error: Column '" << column << "' not found in dataset.\n";
        return;
    }

    // Extract numeric values
    vector<double> values;
    for (auto& row : rows) {
        if (colIdx < row.size()) {
            try { values.push_back(stod(row[colIdx])); }
            catch (...) {}
        }
    }

    if (values.empty()) {
        cerr << "❌ Error: Column '" << column << "' is not numeric or empty.\n";
        return;
    }

    sort(values.begin(), values.end());

    // Compute five-number summary
    double minVal = values.front();
    double q1 = percentile(values, 25);
    double median = percentile(values, 50);
    double q3 = percentile(values, 75);
    double maxVal = values.back();
    double iqr = q3 - q1;
    double lowerWhisker = max(minVal, q1 - 1.5 * iqr);
    double upperWhisker = min(maxVal, q3 + 1.5 * iqr);

    // Find outliers
    vector<double> outliers;
    for (double v : values)
        if (v < lowerWhisker || v > upperWhisker)
            outliers.push_back(v);

    // Print summary
    cout << "\n📊 Five-number summary for column '" << column << "':\n\n";
    cout << fixed << setprecision(2);
    cout << left << setw(20) << "Min" << ": " << minVal << "\n";
    cout << left << setw(20) << "Q1" << ": " << q1 << "\n";
    cout << left << setw(20) << "Median (Q2)" << ": " << median << "\n";
    cout << left << setw(20) << "Q3" << ": " << q3 << "\n";
    cout << left << setw(20) << "Max" << ": " << maxVal << "\n";
    cout << left << setw(20) << "IQR" << ": " << iqr << "\n";
    cout << left << setw(20) << "Lower Whisker" << ": " << lowerWhisker << "\n";
    cout << left << setw(20) << "Upper Whisker" << ": " << upperWhisker << "\n";

    // Print outliers
    if (!outliers.empty()) {
        cout << "\n🚨 Outliers detected:\n";
        for (size_t i = 0; i < outliers.size(); ++i)
            cout << "Value: " << outliers[i] << "\n";
    } else {
        cout << "\n✅ No outliers detected.\n";
    }
}

// ===== MAIN =====
int main() {
    string input_file;
    cout << "Enter input CSV filename (with .csv): ";
    getline(cin, input_file);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(input_file, headers, rows)) return 1;

    string column;
    cout << "Enter column name to generate summary: ";
    getline(cin, column);

    fiveNumberSummary(input_file, column);
    return 0;
}
