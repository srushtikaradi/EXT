#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <cmath>

using namespace std;

// ===== Split a CSV line =====
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) result.push_back(token);
    return result;
}

// ===== Read CSV =====
bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (first) {
            headers = parts;
            first = false;
        } else if (!parts.empty()) {
            rows.push_back(parts);
        }
    }

    if (headers.empty() || rows.empty()) {
        cerr << "❌ Error: Empty or invalid CSV file.\n";
        return false;
    }

    cout << "\n✅ File loaded successfully!\n";
    cout << "Available columns: ";
    for (auto& h : headers) cout << h << "  ";
    cout << "\n";
    return true;
}

// ===== Main Function =====
void t_d_weight_flexible(const string& filename) {
    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(filename, headers, rows)) return;

    // User inputs
    string row_col, col_col, val_col;
    cout << "\nEnter the column name to use as ROW labels: ";
    getline(cin, row_col);
    cout << "Enter the column name to use as COLUMN labels: ";
    getline(cin, col_col);
    cout << "Enter the NUMERIC column name (values to aggregate): ";
    getline(cin, val_col);

    // Validate columns
    int row_idx = find(headers.begin(), headers.end(), row_col) - headers.begin();
    int col_idx = find(headers.begin(), headers.end(), col_col) - headers.begin();
    int val_idx = find(headers.begin(), headers.end(), val_col) - headers.begin();

    if (row_idx >= headers.size() || col_idx >= headers.size() || val_idx >= headers.size()) {
        cerr << "❌ Error: One or more columns not found.\n";
        return;
    }

    // Build pivot table
    map<string, map<string, double>> pivot;
    map<string, double> row_totals, col_totals;
    double grand_total = 0.0;
    vector<string> unique_cols;

    for (auto& row : rows) {
        if (row.size() <= max({row_idx, col_idx, val_idx})) continue;
        string r = row[row_idx];
        string c = row[col_idx];
        double v = 0.0;
        try { v = stod(row[val_idx]); } catch (...) { continue; }

        pivot[r][c] += v;
        row_totals[r] += v;
        col_totals[c] += v;
        grand_total += v;

        if (find(unique_cols.begin(), unique_cols.end(), c) == unique_cols.end())
            unique_cols.push_back(c);
    }

    // Prepare headers
    cout << "\n✅ T-weight & D-weight Table (" << row_col << " vs " << col_col 
         << ") based on '" << val_col << "':\n\n";

    cout << left << setw(15) << (row_col + "\\" + col_col);
    for (auto& c : unique_cols) {
        cout << setw(15) << (c + " (" + val_col + ")");
        cout << setw(15) << (c + " t-weight");
        cout << setw(15) << (c + " d-weight");
    }
    cout << setw(15) << "Total Count";
    cout << setw(15) << "Row t-weight sum";
    cout << setw(15) << "Row d-weight";
    cout << "\n" << string((unique_cols.size() * 45) + 45, '-') << "\n";

    cout << fixed << setprecision(2);

    // Each row
    for (auto& pr : pivot) {
        string row_label = pr.first;
        double row_total = row_totals[row_label];
        double t_sum = 0.0, d_sum = 0.0;

        cout << left << setw(15) << row_label;
        for (auto& c : unique_cols) {
            double count = pr.second.count(c) ? pr.second[c] : 0.0;
            double t_weight = (row_total != 0) ? (count / row_total * 100.0) : 0.0;
            double d_weight = (col_totals[c] != 0) ? (count / col_totals[c] * 100.0) : 0.0;

            t_sum += t_weight;
            d_sum += d_weight;

            cout << setw(15) << count;
            cout << setw(15) << (to_string(t_weight).substr(0,5) + "%");
            cout << setw(15) << (to_string(d_weight).substr(0,5) + "%");
        }

        double row_d_weight = (grand_total != 0) ? (row_total / grand_total * 100.0) : 0.0;

        cout << setw(15) << row_total;
        cout << setw(15) << (to_string(t_sum).substr(0,5) + "%");
        cout << setw(15) << (to_string(row_d_weight).substr(0,5) + "%");
        cout << "\n";
    }

    // ---- TOTAL ROW ----
    cout << left << setw(15) << "Total";
    double total_t_sum = 0.0, total_d_sum = 0.0;

    for (auto& c : unique_cols) {
        double col_total = col_totals[c];
        double t_weight = (grand_total != 0) ? (col_total / grand_total * 100.0) : 0.0;
        double d_weight = 100.0; // by definition total d-weight = 100%

        total_t_sum += t_weight;
        total_d_sum += d_weight;

        cout << setw(15) << col_total;
        cout << setw(15) << (to_string(t_weight).substr(0,5) + "%");
        cout << setw(15) << (to_string(d_weight).substr(0,5) + "%");
    }

    cout << setw(15) << grand_total;
    cout << setw(15) << (to_string(total_t_sum).substr(0,5) + "%");
    cout << setw(15) << (to_string(total_d_sum / unique_cols.size()).substr(0,5) + "%");
    cout << "\n";
}

// ===== MAIN =====
int main() {
    string input_file;
    cout << "Enter input CSV filename (with .csv): ";
    getline(cin, input_file);
    t_d_weight_flexible(input_file);
    return 0;
}
