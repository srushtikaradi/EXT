#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <map>
#include <algorithm>
#include <numeric>

using namespace std;

// ===== CSV Reading =====
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) result.push_back(token);
    return result;
}

bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (first) {
            headers = parts;
            first = false;
        } else if (!parts.empty()) {
            rows.push_back(parts);
        }
    }

    if (headers.empty() || rows.empty()) {
        cerr << "❌ Error: Empty or invalid CSV file.\n";
        return false;
    }

    cout << "\n✅ Loaded file '" << filename << "' successfully.\n";
    cout << "Available columns: ";
    for (auto& h : headers) cout << h << "  ";
    cout << "\n";
    return true;
}

// ===== Display Table =====
void displayTable(const vector<string>& headers, const vector<vector<string>>& rows) {
    cout << "\n--- Data Preview ---\n";
    for (auto& h : headers) cout << left << setw(15) << h;
    cout << "\n" << string(headers.size() * 15, '-') << "\n";
    for (const auto& row : rows) {
        for (auto& cell : row) cout << left << setw(15) << cell;
        cout << "\n";
    }
}

// ===== Slice Operation =====
void sliceOperation(const vector<string>& headers, const vector<vector<string>>& rows) {
    string field;
    cout << "Enter column name to slice by " << "[";
    for (auto& h : headers) cout << h << " ";
    cout << "]: ";
    getline(cin, field);

    int colIndex = find(headers.begin(), headers.end(), field) - headers.begin();
    if (colIndex >= headers.size()) {
        cout << "❌ Invalid column name.\n";
        return;
    }

    string value;
    cout << "Enter value for " << field << ": ";
    getline(cin, value);

    vector<vector<string>> filtered;
    for (const auto& row : rows)
        if (colIndex < row.size() && row[colIndex] == value)
            filtered.push_back(row);

    cout << "\n✅ Slice: " << field << " = " << value << "\n";
    displayTable(headers, filtered);
}

// ===== Dice Operation =====
void diceOperation(const vector<string>& headers, const vector<vector<string>>& rows) {
    int n;
    cout << "How many filters? ";
    if (!(cin >> n) || n <= 0) {
        cout << "❌ Invalid number.\n";
        cin.clear();
        cin.ignore(1000, '\n');
        return;
    }
    cin.ignore();

    vector<pair<int, string>> filters;
    for (int i = 0; i < n; ++i) {
        string col, val;
        cout << "Enter filter column " << "[";
        for (auto& h : headers) cout << h << " ";
        cout << "]: ";
        getline(cin, col);

        int colIndex = find(headers.begin(), headers.end(), col) - headers.begin();
        if (colIndex >= headers.size()) {
            cout << "❌ Invalid column.\n";
            continue;
        }

        cout << "Enter value for " << col << ": ";
        getline(cin, val);
        filters.push_back({colIndex, val});
    }

    vector<vector<string>> filtered = rows;
    for (auto& f : filters) {
        vector<vector<string>> temp;
        for (auto& row : filtered)
            if (f.first < row.size() && row[f.first] == f.second)
                temp.push_back(row);
        filtered = temp;
    }

    cout << "\n✅ Dice operation result:\n";
    displayTable(headers, filtered);
}

// ===== Roll-Up Operation =====
void rollupOperation(const vector<string>& headers, const vector<vector<string>>& rows) {
    string groupCol, numCol;
    cout << "Enter column to group by: ";
    getline(cin, groupCol);
    cout << "Enter numeric column to aggregate: ";
    getline(cin, numCol);

    int groupIdx = find(headers.begin(), headers.end(), groupCol) - headers.begin();
    int numIdx = find(headers.begin(), headers.end(), numCol) - headers.begin();
    if (groupIdx >= headers.size() || numIdx >= headers.size()) {
        cout << "❌ Invalid column(s).\n";
        return;
    }

    map<string, double> grouped;
    for (auto& row : rows) {
        if (numIdx < row.size()) {
            try {
                grouped[row[groupIdx]] += stod(row[numIdx]);
            } catch (...) {}
        }
    }

    cout << "\n✅ Roll-Up: Total " << numCol << " by " << groupCol << "\n";
    cout << left << setw(15) << groupCol << setw(15) << numCol << "\n";
    cout << string(30, '-') << "\n";
    for (auto it = grouped.begin(); it != grouped.end(); ++it)
        cout << left << setw(15) << it->first << setw(15) << it->second << "\n";
}

// ===== Drill-Down =====
void drilldownOperation(const vector<string>& headers, const vector<vector<string>>& rows) {
    cout << "\n✅ Drill-Down: Showing full data\n";
    displayTable(headers, rows);
}

// ===== Pivot Operation =====
void pivotOperation(const vector<string>& headers, const vector<vector<string>>& rows) {
    string rowField, colField, valField;
    cout << "Enter row field: ";
    getline(cin, rowField);
    cout << "Enter column field: ";
    getline(cin, colField);
    cout << "Enter numeric field: ";
    getline(cin, valField);

    int rowIdx = find(headers.begin(), headers.end(), rowField) - headers.begin();
    int colIdx = find(headers.begin(), headers.end(), colField) - headers.begin();
    int valIdx = find(headers.begin(), headers.end(), valField) - headers.begin();

    if (rowIdx >= headers.size() || colIdx >= headers.size() || valIdx >= headers.size()) {
        cout << "❌ Invalid column(s).\n";
        return;
    }

    map<string, map<string, double>> pivot;
    vector<string> colValues;
    for (auto& row : rows) {
        if (rowIdx < row.size() && colIdx < row.size() && valIdx < row.size()) {
            string r = row[rowIdx], c = row[colIdx];
            double v = 0;
            try { v = stod(row[valIdx]); } catch (...) {}
            pivot[r][c] += v;
            if (find(colValues.begin(), colValues.end(), c) == colValues.end())
                colValues.push_back(c);
        }
    }

    cout << "\n✅ Pivot Table: " << rowField << " vs " << colField
         << " (sum of " << valField << ")\n";

    cout << left << setw(15) << rowField;
    for (auto& c : colValues) cout << setw(15) << c;
    cout << "\n" << string((colValues.size() + 1) * 15, '-') << "\n";

    for (auto pit = pivot.begin(); pit != pivot.end(); ++pit) {
        cout << left << setw(15) << pit->first;
        for (auto& c : colValues) {
            if (pit->second.count(c))
                cout << setw(15) << pit->second[c];
            else
                cout << setw(15) << 0;
        }
        cout << "\n";
    }
}

// ===== MAIN MENU =====
int main() {
    string filename;
    cout << "Enter CSV file name (with .csv): ";
    getline(cin, filename);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(filename, headers, rows)) return 1;

    while (true) {
        cout << "\n* OLAP Menu *\n";
        cout << "1. View Original Data\n";
        cout << "2. Slice\n";
        cout << "3. Dice\n";
        cout << "4. Roll-Up\n";
        cout << "5. Drill-Down\n";
        cout << "6. Pivot\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";

        string choice;
        getline(cin, choice);

        if (choice == "1") displayTable(headers, rows);
        else if (choice == "2") sliceOperation(headers, rows);
        else if (choice == "3") diceOperation(headers, rows);
        else if (choice == "4") rollupOperation(headers, rows);
        else if (choice == "5") drilldownOperation(headers, rows);
        else if (choice == "6") pivotOperation(headers, rows);
        else if (choice == "0") { cout << "👋 Exiting... Bye!\n"; break; }
        else cout << "❌ Invalid choice. Please try again.\n";
    }

    return 0;
}
