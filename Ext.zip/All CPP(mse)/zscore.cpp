#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>
#include <cmath> // for sqrt

using namespace std;

// Split CSV line by comma
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        result.push_back(token);
    }
    return result;
}

// Read CSV file into headers and rows
bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool firstLine = true;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (firstLine) {
            headers = parts;
            firstLine = false;
        } else if (!parts.empty()) {
            rows.push_back(parts);
        }
    }

    if (headers.empty() || rows.empty()) {
        cerr << "❌ Error: CSV file is empty or invalid.\n";
        return false;
    }

    return true;
}

// Check if a string can be converted to a number
bool isNumeric(const string& s) {
    if (s.empty()) return false;
    char* end = nullptr;
    strtod(s.c_str(), &end);
    return (*end == '\0');
}

int main() {
    string input_file;
    cout << "Enter input CSV filename (with .csv): ";
    getline(cin, input_file);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(input_file, headers, rows)) {
        return 1;
    }

    // Show available columns
    cout << "\nAvailable columns: ";
    for (const auto& h : headers) cout << h << "  ";
    cout << "\n";

    string column;
    cout << "Enter column name to normalize: ";
    getline(cin, column);

    // Find column index
    int colIndex = -1;
    for (size_t i = 0; i < headers.size(); ++i) {
        if (headers[i] == column) {
            colIndex = static_cast<int>(i);
            break;
        }
    }

    if (colIndex == -1) {
        cerr << "❌ Error: Column '" << column << "' not found in the dataset.\n";
        return 1;
    }

    // Check if numeric
    for (const auto& row : rows) {
        if (colIndex >= static_cast<int>(row.size()) || !isNumeric(row[colIndex])) {
            cerr << "❌ Error: Column '" << column << "' contains non-numeric data.\n";
            return 1;
        }
    }

    // Extract numeric values
    vector<double> values;
    for (const auto& row : rows) {
        values.push_back(stod(row[colIndex]));
    }

    // Compute mean
    double sum = 0.0;
    for (double v : values) sum += v;
    double mean = sum / values.size();

    // Compute standard deviation
    double variance = 0.0;
    for (double v : values) variance += pow(v - mean, 2);
    variance /= values.size();
    double stddev = sqrt(variance);

    // Compute z-scores
    vector<double> zscores(values.size());
    if (stddev == 0) {
        for (auto& z : zscores) z = 0.0;
    } else {
        for (size_t i = 0; i < values.size(); ++i) {
            zscores[i] = (values[i] - mean) / stddev;
        }
    }

    // Display results like Python output
    cout << "\n✅ Z-Score Normalization applied to column '" << column << "':\n\n";
    cout << left << setw(15) << column << setw(20) << (column + "_ZScore") << "\n";
    cout << string(35, '-') << "\n";

    cout << fixed << setprecision(4);
    for (size_t i = 0; i < values.size(); ++i) {
        // Print original naturally
        if (values[i] == static_cast<int>(values[i]))
            cout << left << setw(15) << static_cast<int>(values[i]);
        else
            cout << left << setw(15) << values[i];

        // Print normalized with 4 decimals
        cout << setw(20) << zscores[i] << "\n";
    }

    return 0;
}
