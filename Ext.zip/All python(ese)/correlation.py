import pandas as pd
import numpy as np

# === Step 1: Ask user for CSV file ===
filename = input("Enter CSV filename (with .csv): ").strip()

try:
    # Try reading with header first
    df = pd.read_csv(filename)
except FileNotFoundError:
    print(f"❌ Error: File '{filename}' not found.")
    exit()
except Exception as e:
    print(f"❌ Error reading file: {e}")
    exit()

# === Step 2: Identify item names and numeric data ===
# If the first column is 'Activity' or similar, handle automatically
first_col = df.columns[0]
items = df.iloc[:, 0]

# Convert all other columns to numeric
data = df.iloc[:, 1:].apply(pd.to_numeric, errors="coerce").fillna(0)

# If all numeric columns are empty, something’s wrong
if data.empty or (data.sum().sum() == 0):
    print("❌ No valid numeric data found. Check your file format.")
    exit()

print("\n✅ File loaded successfully!")
print(f"📋 Total activities found: {len(items)}")
print(f"📈 Total pairs to calculate: {len(items) * (len(items) - 1) // 2}\n")

# === Step 3: Compute pairwise correlations ===
results = []

print(f"{'Item 1 (Activity)':<20}{'Item 2 (Activity)':<20}"
      f"{'Pearson Correlation Coefficient':<35}{'Type of Correlation'}")
print("-" * 95)

for i in range(len(items)):
    for j in range(i + 1, len(items)):
        x = data.iloc[i].values
        y = data.iloc[j].values

        # Check if both rows have variation (avoid divide by zero)
        if np.std(x) == 0 or np.std(y) == 0:
            r = 0
        else:
            r = np.corrcoef(x, y)[0, 1]

        # Interpret correlation
        if np.isnan(r) or np.isclose(r, 0):
            corr_type = "No correlation ⚪"
        elif np.isclose(r, 1):
            corr_type = "Perfect positive correlation ✅"
        elif np.isclose(r, -1):
            corr_type = "Perfect negative correlation 🔴"
        elif r > 0:
            corr_type = "Positive correlation 📈"
        else:
            corr_type = "Negative correlation 📉"

        results.append([items[i], items[j], round(r, 3), corr_type])

        print(f"{items[i]:<20}{items[j]:<20}{r:<35.3f}{corr_type}")
