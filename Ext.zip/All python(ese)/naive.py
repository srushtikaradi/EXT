import pandas as pd

# ---------- Function to calculate P(attribute | class) ----------
def calculate_attribute_likelihood(attribute_value, df, feature, class_label, target_col):
    class_subset = df[df[target_col] == class_label]
    total_in_class = len(class_subset)
    if total_in_class == 0:
        return 0.0
    attribute_match_count = len(class_subset[class_subset[feature] == attribute_value])
    return attribute_match_count / total_in_class


# ---------- Function to calculate likelihood for new case ----------
def calculate_likelihood(new_case, df, class_label, target_col):
    likelihood = 1.0
    for feature, value in new_case.items():
        likelihood *= calculate_attribute_likelihood(value, df, feature, class_label, target_col)
    return likelihood


# ---------- Main Program ----------
def main():
    print("=== Naive Bayes Classifier ===\n")
    filename = input("Enter the CSV filename (with .csv): ").strip()

    try:
        df = pd.read_csv(filename)
    except FileNotFoundError:
        print(f"❌ Error: File '{filename}' not found.")
        return
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return

    print("\n✅ File loaded successfully!")
    print("Available columns:", ", ".join(df.columns))

    target_col = df.columns[-1]  # assume last column is class label
    features = df.columns[:-1]

    print(f"\n🎯 Target column detected as: '{target_col}'")
    print("\nEnter values for the new case:")
    new_case = {}

    for feature in features:
        val = input(f"{feature}: ").strip()
        new_case[feature] = val

    # --- Calculate priors ---
    total = len(df)
    class_labels = df[target_col].unique()
    priors = {}
    for label in class_labels:
        priors[label] = len(df[df[target_col] == label]) / total

    print("\n📊 Prior Probabilities:")
    for label, p in priors.items():
        print(f"P({label}) = {p:.4f}")

    # --- Calculate likelihoods ---
    print("\n📈 Likelihoods for Each Attribute:")
    print(f"{'Attribute':<15}{'P(attr|Yes)':<20}{'P(attr|No)':<20}")
    print("-" * 55)

    likelihoods = {label: 1.0 for label in class_labels}
    for feature, value in new_case.items():
        for label in class_labels:
            p_attr_given_class = calculate_attribute_likelihood(value, df, feature, label, target_col)
            likelihoods[label] *= p_attr_given_class
        # Print row
        yes_l = calculate_attribute_likelihood(value, df, feature, class_labels[0], target_col)
        no_l = calculate_attribute_likelihood(value, df, feature, class_labels[1], target_col)
        print(f"{value:<15}{yes_l:<20.6f}{no_l:<20.6f}")

    # --- Calculate posterior probabilities ---
    posteriors = {}
    for label in class_labels:
        posteriors[label] = priors[label] * calculate_likelihood(new_case, df, label, target_col)

    print("\n🧮 Posterior Probabilities:")
    for label, p in posteriors.items():
        print(f"P({label} | New Case) = {p:.6f}")

    # --- Classify based on higher posterior ---
    best_label = max(posteriors, key=posteriors.get)
    print(f"\n✅ Classified as: **{best_label}**")

if __name__ == "__main__":
    main()
