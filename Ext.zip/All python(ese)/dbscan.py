import pandas as pd
import numpy as np
import math

# === Euclidean distance between two points ===
def distance(a, b):
    return math.sqrt(np.sum((np.array(a) - np.array(b)) ** 2))

# === Compute cluster centroid ===
def centroid(cluster):
    data = np.array([p[1] for p in cluster])
    return np.mean(data, axis=0)

# === Region query: find neighbors within epsilon ===
def region_query(points, idx, eps):
    neighbors = []
    for j, (_, p) in enumerate(points):
        if distance(points[idx][1], p) <= eps:
            neighbors.append(j)
    return neighbors

# === Expand a cluster starting from a core point ===
def expand_cluster(points, clusters, cluster_id, idx, neighbors, eps, min_pts):
    clusters[idx] = cluster_id
    queue = list(neighbors)

    while queue:
        q_idx = queue.pop(0)
        if clusters[q_idx] == -1:  # noise -> assign to cluster
            clusters[q_idx] = cluster_id
        elif clusters[q_idx] == 0:  # unvisited
            clusters[q_idx] = cluster_id
            q_neighbors = region_query(points, q_idx, eps)
            if len(q_neighbors) >= min_pts:
                queue.extend(q_neighbors)

# === DBSCAN main algorithm ===
def dbscan(points, eps, min_pts):
    n = len(points)
    clusters = [0] * n  # 0 = unvisited, -1 = noise
    cluster_id = 0

    for i in range(n):
        if clusters[i] != 0:
            continue
        neighbors = region_query(points, i, eps)
        if len(neighbors) < min_pts:
            clusters[i] = -1  # mark as noise
        else:
            cluster_id += 1
            expand_cluster(points, clusters, cluster_id, i, neighbors, eps, min_pts)

    cluster_map = {}
    for idx, c_id in enumerate(clusters):
        if c_id > 0:
            cluster_map.setdefault(c_id, []).append(points[idx])

    return list(cluster_map.values()), clusters


# === Distance matrix for reference (optional pretty print) ===
def compute_distance_matrix(points):
    n = len(points)
    names = [p[0] for p in points]
    matrix = np.zeros((n, n))

    for i in range(n):
        for j in range(i + 1, n):
            d = distance(points[i][1], points[j][1])
            matrix[i][j] = matrix[j][i] = d

    print("\n📏 Distance Matrix:")
    print(" " * 12 + " ".join(f"{name:>10}" for name in names))
    for i, row in enumerate(matrix):
        print(f"{names[i]:<10}  " + " ".join(f"{x:>10.3f}" for x in row))

    return matrix


# === MAIN PROGRAM ===
def main():
    # Step 1: Load CSV
    filename = input("Enter CSV filename (with .csv): ").strip()

    try:
        df = pd.read_csv(filename)
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found.")
        return
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return

    print("\n✅ File loaded successfully!")
    print("Available columns:")
    for i, col in enumerate(df.columns):
        print(f"{i}. {col}")

    # Step 2: Ask user for columns to cluster
    col_input = input("\nEnter column names to use for clustering (comma-separated): ").strip()
    selected_cols = [c.strip() for c in col_input.split(",") if c.strip() in df.columns]

    if not selected_cols:
        print("❌ No valid columns selected.")
        return

    # Step 3: Convert selected columns to numeric
    df[selected_cols] = df[selected_cols].apply(pd.to_numeric, errors='coerce')
    df = df.dropna(subset=selected_cols)

    # Step 4: Prepare data points (labels = P1, P2, ...)
    points = [(f"P{i+1}", df.iloc[i][selected_cols].values.tolist()) for i in range(len(df))]

    # Step 5: Display distance matrix
    compute_distance_matrix(points)

    # Step 6: Ask DBSCAN parameters
    eps = float(input("\nEnter epsilon (neighborhood radius): "))
    min_pts = int(input("Enter minPts (minimum neighbors): "))

    # Step 7: Run DBSCAN
    clusters, cluster_assignments = dbscan(points, eps, min_pts)

    total_points = len(points)
    print("\n✅ Results:")
    for i, cluster in enumerate(clusters, start=1):
        percent = len(cluster) * 100.0 / total_points
        names = [p[0] for p in cluster]
        print(f"Cluster {i}: {len(cluster)} points ({percent:.2f}%) → {names}")

    # Noise points
    noise_points = [points[i][0] for i, c in enumerate(cluster_assignments) if c == -1]
    if noise_points:
        noise_count = len(noise_points)
        noise_percent = noise_count * 100.0 / total_points
        print(f"Noise points: {noise_count} ({noise_percent:.2f}%) → {noise_points}")
    else:
        print("No noise points detected 🎯")

    # Step 8: Print centroids
    print("\n📍 Centroids:")
    for i, cluster in enumerate(clusters, start=1):
        c = centroid(cluster)
        print(f"Centroid {i}: [{', '.join(f'{x:.3f}' for x in c)}]")


if __name__ == "__main__":
    main()
