import pandas as pd
import numpy as np

# === Step 1: Ask user for CSV file ===
filename = input("Enter CSV filename (with .csv): ").strip()

try:
    df = pd.read_csv(filename)
except FileNotFoundError:
    print(f"❌ Error: File '{filename}' not found.")
    exit()
except Exception as e:
    print(f"❌ Error reading file: {e}")
    exit()

print("\n✅ File loaded successfully!")
print("Available columns:")
for i, col in enumerate(df.columns):
    print(f"{i}. {col}")

# === Step 2: Choose two columns for clustering ===
x_col = input("\nEnter first column name (X): ").strip()
y_col = input("Enter second column name (Y): ").strip()

if x_col not in df.columns or y_col not in df.columns:
    print("❌ Invalid column names.")
    exit()

# Convert selected columns to numeric NumPy arrays
data = df[[x_col, y_col]].apply(pd.to_numeric, errors='coerce').dropna().to_numpy()

if data.shape[0] == 0:
    print("❌ No valid numeric data found in selected columns.")
    exit()

# === Step 3: Ask user for number of clusters (k) ===
k = int(input("\nEnter number of clusters (k): "))

# === Step 4: Get initial centroids from user ===
centroids = np.zeros((k, 2))
print("\nEnter initial centroids (x y):")
for i in range(k):
    cx, cy = map(float, input(f"Centroid {i+1}: ").split())
    centroids[i] = [cx, cy]

# === Step 5: K-Means main loop ===
max_iterations = 100
tolerance = 1e-4
iterations = 0

while True:
    iterations += 1

    # Step 1: Compute distances (Euclidean)
    distances = np.linalg.norm(data[:, np.newaxis] - centroids, axis=2)

    # Step 2: Assign each point to nearest centroid
    assignments = np.argmin(distances, axis=1)

    # Step 3: Update centroids
    new_centroids = np.array([
        data[assignments == i].mean(axis=0) if np.any(assignments == i) else centroids[i]
        for i in range(k)
    ])

    # Display progress
    print(f"\nIteration {iterations}:")
    for idx, c in enumerate(new_centroids):
        print(f"  Centroid {idx+1}: ({c[0]:.4f}, {c[1]:.4f})")

    # Check for convergence
    if np.all(np.linalg.norm(new_centroids - centroids, axis=1) < tolerance) or iterations >= max_iterations:
        centroids = new_centroids
        break

    centroids = new_centroids

# === Step 6: Final Output ===
print("\n✅ Final Cluster Assignments:")
print(f"{'X':<10}{'Y':<10}{'Cluster':<10}")
print("-" * 30)
for point, cluster in zip(data, assignments):
    print(f"{point[0]:<10.4f}{point[1]:<10.4f}{cluster + 1:<10}")

print(f"\n📊 Total iterations: {iterations}")
print("📍 Final Centroids:")
for i, c in enumerate(centroids):
    print(f"  Cluster {i+1}: ({c[0]:.4f}, {c[1]:.4f})")
