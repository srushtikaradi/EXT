import pandas as pd
import math

# === Distance between two scalar values ===
def distance(a, b):
    return abs(a - b)

# === Compute centroid of a cluster ===
def centroid(cluster):
    mean = sum(p[1] for p in cluster) / len(cluster)
    return mean

# === Linkage distance between two clusters ===
def linkage_distance(clusterA, clusterB, method):
    if method == "single":
        return min(distance(a[1], b[1]) for a in clusterA for b in clusterB)
    elif method == "complete":
        return max(distance(a[1], b[1]) for a in clusterA for b in clusterB)
    else:  # average linkage
        total = sum(distance(a[1], b[1]) for a in clusterA for b in clusterB)
        count = len(clusterA) * len(clusterB)
        return total / count

# === Nicely formatted distance matrix ===
def print_distance_matrix(clusters, method):
    n = len(clusters)
    matrix = [[0.0] * n for _ in range(n)]
    labels = [",".join(p[0] for p in cluster) for cluster in clusters]

    # Compute matrix
    for i in range(n):
        for j in range(i + 1, n):
            d = linkage_distance(clusters[i], clusters[j], method)
            matrix[i][j] = d
            matrix[j][i] = d

    # Print header
    print("\n📏 Distance Matrix:")
    col_width = 10
    print(" " * (col_width + 2), end="")
    for lbl in labels:
        print(f"{lbl:>{col_width}}", end=" ")
    print()

    # Print rows
    for i in range(n):
        print(f"{labels[i]:<{col_width}}", end="  ")
        for j in range(n):
            print(f"{matrix[i][j]:>{col_width}.3f}", end=" ")
        print()

# === Print clusters and centroids ===
def print_clusters(clusters):
    print("\n📊 Current Clusters and Centroids:")
    for i, cluster in enumerate(clusters):
        names = [p[0] for p in cluster]
        c = centroid(cluster)
        print(f"Cluster {i+1:2}: {len(cluster)} points {names}, Centroid = [{c:.3f}]")

# === Main hierarchical clustering ===
def hierarchical_cluster(points, method):
    clusters = [[p] for p in points]
    iteration = 1

    while len(clusters) > 1:
        print(f"\n--- Iteration {iteration} ---")
        print_clusters(clusters)
        print_distance_matrix(clusters, method)

        min_dist = float("inf")
        mergeA, mergeB = -1, -1
        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):
                d = linkage_distance(clusters[i], clusters[j], method)
                if d < min_dist:
                    min_dist = d
                    mergeA, mergeB = i, j

        print(f"\n🔗 Merging clusters {mergeA+1} and {mergeB+1} (distance={min_dist:.3f})")
        clusters[mergeA].extend(clusters[mergeB])
        clusters.pop(mergeB)
        iteration += 1

    print("\n✅ --- Final Cluster ---")
    final_cluster = clusters[0]
    final_names = [p[0] for p in final_cluster]
    final_centroid = centroid(final_cluster)
    print(f"Final Cluster: {len(final_cluster)} points {final_names}")
    print(f"Centroid: [{final_centroid:.3f}]")

# === Main program ===
def main():
    # Step 1: Ask user for CSV
    filename = input("Enter the CSV filename (with .csv): ").strip()

    try:
        df = pd.read_csv(filename)
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found.")
        return
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return

    print("\n✅ File loaded successfully!")
    print("Available columns:")
    for col in df.columns:
        print(f"- {col}")

    # Step 2: Ask for one column name
    col_name = input("\nEnter the column name for clustering: ").strip()
    if col_name not in df.columns:
        print("❌ Invalid column name.")
        return

    # Step 3: Convert selected column to numeric
    df[col_name] = pd.to_numeric(df[col_name], errors="coerce")
    df = df.dropna(subset=[col_name])

    # Step 4: Prepare points (row name = P#, value = numeric)
    points = [(f"P{i+1}", val) for i, val in enumerate(df[col_name])]

    # Step 5: Choose linkage method
    method = input("\nEnter linkage method (single / average / complete): ").strip().lower()
    if method not in ["single", "average", "complete"]:
        print("❌ Invalid linkage method.")
        return

    # Step 6: Run clustering
    hierarchical_cluster(points, method)

if __name__ == "__main__":
    main()
