import pandas as pd
import numpy as np

# Step 1: Ask for CSV file name
csv_file = input("Enter CSV filename (with .csv): ").strip()

try:
    df = pd.read_csv(csv_file)
except FileNotFoundError:
    print(f"❌ Error: File '{csv_file}' not found.")
    exit()
except Exception as e:
    print(f"❌ Error reading file: {e}")
    exit()

print("\n✅ File loaded successfully!")
print("Available columns:", list(df.columns))

# Step 2: Ask user for X and Y columns
x_col = input("Enter column name for X: ").strip()
y_col = input("Enter column name for Y: ").strip()

if x_col not in df.columns or y_col not in df.columns:
    print("❌ Invalid column names.")
    exit()

# Step 3: Convert columns to numeric and drop missing values
df[[x_col, y_col]] = df[[x_col, y_col]].apply(pd.to_numeric, errors='coerce')
df = df.dropna(subset=[x_col, y_col])

if df.empty:
    print("❌ No valid numeric data found in selected columns.")
    exit()

# Step 4: Compute Pearson correlation
r = np.corrcoef(df[x_col], df[y_col])[0, 1]

# Step 5: Display result and interpretation
print(f"\n📊 Pearson correlation coefficient (r): {r:.4f}")

if np.isclose(r, 1):
    print("Perfect positive correlation ✅")
elif np.isclose(r, -1):
    print("Perfect negative correlation 🔴")
elif r > 0:
    print("Positive correlation 📈")
elif r < 0:
    print("Negative correlation 📉")
else:
    print("No correlation ⚪")
