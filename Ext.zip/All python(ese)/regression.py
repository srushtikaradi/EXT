import pandas as pd

# --- Step 1: Ask user for CSV file ---
filename = input("Enter CSV filename (with .csv): ").strip()

try:
    df = pd.read_csv(filename)
except FileNotFoundError:
    print(f"❌ Error: File '{filename}' not found.")
    exit()
except Exception as e:
    print(f"❌ Error reading file: {e}")
    exit()

# --- Step 2: Display available columns ---
print("\n✅ File loaded successfully!")
print("Available columns:")
for i, col in enumerate(df.columns):
    print(f"{i}. {col}")

# --- Step 3: Let user choose X and Y columns ---
x_col = input("\nEnter column name for X: ").strip()
y_col = input("Enter column name for Y: ").strip()

if x_col not in df.columns or y_col not in df.columns:
    print("❌ Invalid column names.")
    exit()

# --- Step 4: Convert to numeric and remove NaN values ---
df[x_col] = pd.to_numeric(df[x_col], errors='coerce')
df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
df = df.dropna(subset=[x_col, y_col])

x = df[x_col].tolist()
y = df[y_col].tolist()
n = len(x)

if n == 0:
    print("❌ No valid numeric data found.")
    exit()

# --- Step 5: Compute regression coefficients (your same formula) ---
sum_x = sum(x)
sum_y = sum(y)
sum_xy = sum(x[i] * y[i] for i in range(n))
sum_x2 = sum(val ** 2 for val in x)

denominator = (n * sum_x2) - (sum_x ** 2)
if denominator == 0:
    print("❌ Cannot compute regression — denominator is zero.")
    exit()

b = ((n * sum_xy) - (sum_x * sum_y)) / denominator  # slope (m)
a = ((sum_y * sum_x2) - (sum_x * sum_xy)) / denominator  # intercept (c)

# --- Step 6: Print result ---
if a >= 0:
    equation = f"Y = {b:.3f}X + {a:.3f}"
else:
    equation = f"Y = {b:.3f}X - {abs(a):.3f}"

print("\n📈 Linear Regression Results:")
print(f"Equation: {equation}")
print(f"Intercept (c): {a:.3f}")
print(f"Slope (m): {b:.3f}")
