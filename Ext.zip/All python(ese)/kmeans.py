import pandas as pd
import numpy as np

# === Step 1: Ask user for CSV file ===
filename = input("Enter CSV filename (with .csv): ").strip()

try:
    df = pd.read_csv(filename)
except FileNotFoundError:
    print(f"❌ Error: File '{filename}' not found.")
    exit()
except Exception as e:
    print(f"❌ Error reading file: {e}")
    exit()

print("\n✅ File loaded successfully!")
print("Available columns:")
for i, col in enumerate(df.columns):
    print(f"{i}. {col}")

# === Step 2: Choose column for clustering ===
col_name = input("\nEnter the column name for clustering: ").strip()
if col_name not in df.columns:
    print("❌ Invalid column name.")
    exit()

# Convert the chosen column to a numeric NumPy array
data = pd.to_numeric(df[col_name], errors='coerce').dropna().to_numpy()
if len(data) == 0:
    print("❌ No valid numeric data found in selected column.")
    exit()

# === Step 3: Ask user for number of clusters (k) ===
k = int(input("\nEnter the number of clusters (k): "))

# === Step 4: Get initial centroids from user ===
centroids = np.zeros(k)
print("\nEnter initial centroids:")
for i in range(k):
    centroids[i] = float(input(f"Centroid {i+1}: "))

# === Step 5: K-Means main loop ===
max_iterations = 100
tolerance = 1e-4
iterations = 0

while True:
    iterations += 1

    # Step 1: Assign points to nearest centroid
    distances = np.abs(data.reshape(-1, 1) - centroids)  # |x - c|
    assignments = np.argmin(distances, axis=1)

    # Step 2: Recalculate centroids
    new_centroids = np.array([
        np.mean(data[assignments == i]) if np.any(assignments == i) else centroids[i]
        for i in range(k)
    ])

    # Display progress
    print(f"\nIteration {iterations}: Centroids = {' '.join(f'{c:.4f}' for c in new_centroids)}")

    # Check for convergence
    if np.all(np.abs(new_centroids - centroids) < tolerance) or iterations >= max_iterations:
        centroids = new_centroids
        break

    centroids = new_centroids

# === Step 6: Final output ===
print("\n✅ Final Cluster Assignments:")
print(f"{'Value':<10}{'Cluster':<10}")
print("-" * 20)
for val, cluster in zip(data, assignments):
    print(f"{val:<10.4f}{cluster + 1:<10}")

print(f"\n📊 Total iterations: {iterations}")
print(f"📍 Final centroids: {', '.join(f'{c:.4f}' for c in centroids)}")
