import pandas as pd
import itertools

def read_transactions(csv_file):
    """Read transactions from a CSV file."""
    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"❌ Error: File '{csv_file}' not found.")
        return []

    # If dataset has a header with "Items", use that column
    if "Items" in df.columns:
        transactions = []
        for items in df["Items"]:
            if isinstance(items, str):
                transactions.append(set(i.strip() for i in items.split(",") if i.strip()))
        return transactions
    else:
        # Otherwise, assume each row represents items
        transactions = []
        for _, row in df.iterrows():
            items = {str(i).strip() for i in row if pd.notna(i) and str(i).strip()}
            if items:
                transactions.append(items)
        return transactions


def get_combinations(transaction, size):
    """Generate all possible item combinations of a given size."""
    return list(itertools.combinations(transaction, size))


def get_itemset_counts(transactions, size):
    """Count occurrences of all itemsets of a given size."""
    itemset_counts = {}
    for transaction in transactions:
        if len(transaction) >= size:
            for combination in get_combinations(transaction, size):
                combo = frozenset(combination)
                itemset_counts[combo] = itemset_counts.get(combo, 0) + 1
    return itemset_counts


def print_frequent_itemsets(itemset_counts, total_transactions, min_support):
    """Print frequent itemsets that meet the support threshold."""
    frequent_itemsets = {}
    for itemset, count in itemset_counts.items():
        support = count / total_transactions
        if support >= min_support:
            items = ", ".join(sorted(itemset))
            print(f"Item set: {{ {items} }} | Support: {support:.2f} | Count: {count}")
            frequent_itemsets[itemset] = count
    return frequent_itemsets


def generate_next_itemsets(previous_itemsets, transactions, size):
    """Generate and count next-level candidate itemsets."""
    next_itemsets = set()
    prev_list = list(previous_itemsets)
    for i in range(len(prev_list)):
        for j in range(i + 1, len(prev_list)):
            union_set = prev_list[i].union(prev_list[j])
            if len(union_set) == size:
                next_itemsets.add(union_set)

    # Count frequencies of generated itemsets
    itemset_counts = {}
    for transaction in transactions:
        for itemset in next_itemsets:
            if itemset.issubset(transaction):
                itemset_counts[itemset] = itemset_counts.get(itemset, 0) + 1
    return itemset_counts


def apriori(csv_file, min_support):
    """Run the Apriori algorithm."""
    transactions = read_transactions(csv_file)
    if not transactions:
        print("❌ No transactions found or file format invalid.")
        return

    total_transactions = len(transactions)
    print(f"\n✅ Total Transactions: {total_transactions}")

    k = 1
    current_counts = get_itemset_counts(transactions, k)
    all_frequent_itemsets = {}

    while current_counts:
        print(f"\n{k}-itemsets with support ≥ {min_support}:")
        frequent_itemsets = print_frequent_itemsets(current_counts, total_transactions, min_support)
        if not frequent_itemsets:
            break

        all_frequent_itemsets.update(frequent_itemsets)
        prev_itemsets = list(frequent_itemsets.keys())
        k += 1
        current_counts = generate_next_itemsets(prev_itemsets, transactions, k)

    print("\n✅ Apriori Mining Completed.")
    print(f"Total Frequent Itemsets Found: {len(all_frequent_itemsets)}")


# ---- MAIN PROGRAM ----
if __name__ == "__main__":
    csv_file = input("Enter CSV filename (with .csv): ").strip()
    try:
        min_support = float(input("Enter minimum support (e.g., 0.3): ").strip())
    except ValueError:
        print("❌ Invalid support value.")
        exit()

    apriori(csv_file, min_support)
