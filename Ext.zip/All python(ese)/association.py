import pandas as pd
import itertools

# ---------------- Helper Functions ----------------

def read_transactions(csv_file):
    """Read CSV file and load transactions as a list of sets."""
    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"❌ Error: File '{csv_file}' not found.")
        return []

    transactions = []
    for _, row in df.iterrows():
        # Combine all non-empty items in the row into a set
        items = {str(i).strip() for i in row if pd.notna(i) and str(i).strip()}
        if items:
            transactions.append(items)
    return transactions


def get_combinations(items, size):
    """Generate all combinations of given size."""
    return list(itertools.combinations(items, size))


def get_itemset_counts(transactions, size):
    """Count all itemsets of a given size."""
    itemset_counts = {}
    for transaction in transactions:
        if len(transaction) >= size:
            for combo in itertools.combinations(transaction, size):
                combo_set = frozenset(combo)
                itemset_counts[combo_set] = itemset_counts.get(combo_set, 0) + 1
    return itemset_counts


def print_frequent_itemsets(itemset_counts, total_transactions, min_support):
    """Print itemsets meeting min support threshold."""
    frequent_itemsets = {}
    print(f"{'Itemset':<35} {'Count':<10} {'Support (%)':<12}")
    print("-" * 60)

    for itemset, count in itemset_counts.items():
        support = (count / total_transactions) * 100
        if support >= min_support * 100:
            frequent_itemsets[itemset] = count
            items = ", ".join(sorted(itemset))
            print(f"{{ {items} }}".ljust(35), f"{count:<10}", f"{support:.2f}")
    return frequent_itemsets


def all_subsets_frequent(combination, prev_itemsets):
    """Check if all (k-1)-subsets of a combination are frequent."""
    for item in combination:
        subset = frozenset(set(combination) - {item})
        if subset not in prev_itemsets:
            return False
    return True


def generate_next_itemsets(prev_itemsets, transactions, size):
    """Generate next level of candidate itemsets and count them."""
    next_candidates = set()
    prev_list = list(prev_itemsets)

    # Join step: combine previous frequent itemsets
    for i in range(len(prev_list)):
        for j in range(i + 1, len(prev_list)):
            union_set = prev_list[i].union(prev_list[j])
            if len(union_set) == size and all_subsets_frequent(union_set, prev_itemsets):
                next_candidates.add(union_set)

    # Count step
    itemset_counts = {}
    for transaction in transactions:
        for candidate in next_candidates:
            if candidate.issubset(transaction):
                itemset_counts[candidate] = itemset_counts.get(candidate, 0) + 1
    return itemset_counts


def find_association_rules(frequent_itemsets, min_confidence, total_transactions):
    """Generate association rules and print those meeting confidence threshold."""
    print(f"\nASSOCIATION RULES (Confidence ≥ {min_confidence * 100:.0f}%)")
    print("=" * 70)
    print(f"{'Rule':<45} {'Confidence (%)':<15}")
    print("-" * 70)

    for itemset, itemset_count in frequent_itemsets.items():
        if len(itemset) > 1:
            for i in range(1, len(itemset)):
                for subset in itertools.combinations(itemset, i):
                    subset = frozenset(subset)
                    remaining = itemset - subset
                    subset_count = frequent_itemsets.get(subset, 0)
                    if subset_count > 0:
                        confidence = (itemset_count / subset_count) * 100
                        if confidence >= min_confidence * 100:
                            lhs = ", ".join(sorted(subset))
                            rhs = ", ".join(sorted(remaining))
                            print(f"{{ {lhs} }} → {{ {rhs} }}".ljust(45), f"{confidence:.2f}")


# ---------------- Main Apriori Function ----------------

def apriori(csv_file, min_support, min_confidence):
    transactions = read_transactions(csv_file)
    if not transactions:
        print("❌ No valid transactions found.")
        return

    total_transactions = len(transactions)
    print(f"\n✅ Total Transactions: {total_transactions}")

    k = 1
    current_counts = get_itemset_counts(transactions, k)
    all_frequent_itemsets = {}

    # Generate frequent itemsets
    while current_counts:
        print(f"\n{k}-ITEMSETS (Support ≥ {min_support * 100:.0f}%)")
        print("=" * 60)
        frequent_itemsets = print_frequent_itemsets(current_counts, total_transactions, min_support)

        if not frequent_itemsets:
            break

        all_frequent_itemsets.update(frequent_itemsets)
        prev_itemsets = list(frequent_itemsets.keys())
        k += 1
        current_counts = generate_next_itemsets(prev_itemsets, transactions, k)

    # Generate and print association rules
    find_association_rules(all_frequent_itemsets, min_confidence, total_transactions)

    print("\n--- END OF ANALYSIS ---")


# ---------------- Program Entry ----------------
if __name__ == "__main__":
    csv_file = input("Enter CSV filename (with .csv): ").strip()

    try:
        min_support = float(input("Enter Minimum Support (e.g., 0.2): ").strip())
        min_confidence = float(input("Enter Minimum Confidence (e.g., 0.6): ").strip())
    except ValueError:
        print("❌ Invalid numeric input.")
        exit()

    apriori(csv_file, min_support, min_confidence)
