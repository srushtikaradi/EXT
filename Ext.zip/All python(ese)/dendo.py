import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram
from scipy.spatial.distance import pdist
import numpy as np

# === Step 1: Read CSV file ===
filename = input("Enter the CSV filename (with .csv): ").strip()

try:
    df = pd.read_csv(filename)
except FileNotFoundError:
    print(f"Error: File '{filename}' not found.")
    exit()
except Exception as e:
    print(f"Error reading file: {e}")
    exit()

print("\nFile loaded successfully!")
print("Available columns:")
for col in df.columns:
    print(f"- {col}")

# === Step 2: Ask for column names ===
cols_input = input("\nEnter column names for clustering (comma-separated): ").strip()
selected_cols = [c.strip() for c in cols_input.split(",") if c.strip() in df.columns]

if not selected_cols:
    print("Error: No valid columns selected.")
    exit()

# Convert selected columns to numeric
df[selected_cols] = df[selected_cols].apply(pd.to_numeric, errors="coerce")
df = df.dropna(subset=selected_cols)

# === Step 3: Prepare data ===
values = df[selected_cols].to_numpy()
if values.shape[0] < 2:
    print("Error: Not enough valid data points for clustering.")
    exit()

print(f"\nSelected columns for clustering: {', '.join(selected_cols)}")
print(f"Total data points used: {len(values)}")

# === Step 4: Choose linkage method ===
method = input("\nEnter linkage method (single / average / complete): ").strip().lower()
if method not in ["single", "average", "complete"]:
    print("Error: Invalid linkage method.")
    exit()

# === Step 5: Perform hierarchical clustering ===
linked = linkage(values, method=method, metric='euclidean')

# === Step 6: Plot dendrogram ===
plt.figure(figsize=(8, 5))
dendrogram(
    linked,
    labels=[f"P{i+1}" for i in range(len(values))],
    distance_sort='ascending',
    show_leaf_counts=True,
    leaf_font_size=10
)

plt.title(f"Hierarchical Clustering Dendrogram ({method.capitalize()} Linkage)")
plt.xlabel("Data Points")
plt.ylabel("Euclidean Distance")
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
