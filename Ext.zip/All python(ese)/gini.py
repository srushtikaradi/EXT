import pandas as pd
import numpy as np
import math

# === Entropy Calculation ===
def entropy(class_counts):
    total = sum(class_counts.values())
    if total == 0:
        return 0
    probs = np.array(list(class_counts.values())) / total
    return -np.sum(probs * np.log2(probs, where=(probs != 0)))

# === Gini Index Calculation ===
def gini_index(class_counts):
    total = sum(class_counts.values())
    if total == 0:
        return 0
    probs = np.array(list(class_counts.values())) / total
    return 1 - np.sum(probs ** 2)

# === Count class occurrences ===
def class_counts(df, label_col):
    return df[label_col].value_counts().to_dict()

# === Split categorical ===
def split_categorical(df, feature):
    return {val: subset for val, subset in df.groupby(feature)}

# === Split numerical (binary split at median) ===
def split_numerical(df, feature):
    median = df[feature].median()
    left = df[df[feature] <= median]
    right = df[df[feature] > median]
    return {f"≤{median:.3f}": left, f">{median:.3f}": right}

# === Information Gain ===
def info_gain(df, feature, label_col):
    base_entropy = entropy(class_counts(df, label_col))
    total_len = len(df)
    
    # detect numerical/categorical
    if pd.api.types.is_numeric_dtype(df[feature]):
        splits = split_numerical(df, feature)
    else:
        splits = split_categorical(df, feature)
    
    weighted_entropy = sum(
        (len(subset) / total_len) * entropy(class_counts(subset, label_col))
        for subset in splits.values()
    )
    return base_entropy - weighted_entropy

# === Weighted Gini Index ===
def gini_gain(df, feature, label_col):
    total_len = len(df)
    if pd.api.types.is_numeric_dtype(df[feature]):
        splits = split_numerical(df, feature)
    else:
        splits = split_categorical(df, feature)
    
    weighted_gini = sum(
        (len(subset) / total_len) * gini_index(class_counts(subset, label_col))
        for subset in splits.values()
    )
    return weighted_gini

# === Main Program ===
def main():
    filename = input("Enter CSV filename (with .csv): ").strip()

    try:
        df = pd.read_csv(filename)
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found.")
        return
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return

    print("\n✅ File loaded successfully!\n")
    print("Available columns:", ", ".join(df.columns))

    # Assume last column is the target (label)
    label_col = df.columns[-1]
    features = df.columns[:-1]

    print(f"\n🎯 Target column detected as: '{label_col}'")
    print(f"\n🔹 Calculating Information Gain and Gini Index...\n")

    results = []

    for feature in features:
        ig = info_gain(df, feature, label_col)
        gini = gini_gain(df, feature, label_col)
        results.append((feature, ig, gini))

    results_df = pd.DataFrame(results, columns=["Feature", "Information Gain", "Gini Index"])

    # Best features
    best_gain_feature = results_df.iloc[results_df["Information Gain"].idxmax()]["Feature"]
    best_gini_feature = results_df.iloc[results_df["Gini Index"].idxmin()]["Feature"]

    print("📊 Results Table:\n")
    print(results_df.to_string(index=False, formatters={
        "Information Gain": "{:.4f}".format,
        "Gini Index": "{:.4f}".format
    }))

    print("\n🏆 Best Attribute for Splitting:")
    print(f"➡️  Based on Information Gain (ID3/C4.5): **{best_gain_feature}**")
    print(f"➡️  Based on Gini Index (CART): **{best_gini_feature}**")

if __name__ == "__main__":
    main()
