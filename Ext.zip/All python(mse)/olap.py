import pandas as pd
import numpy as np

def load_data(filename):
    try:
        df = pd.read_csv(filename)
        print(f"\n✅ Loaded file '{filename}' successfully.")
        print(f"Available columns: {list(df.columns)}")
        return df
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found.")
        return None
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return None


def display_dataframe(df):
    print("\n--- Data Preview ---")
    print(df.to_string(index=False))


def slice_operation(df):
    field = input(f"Enter column name to slice by {list(df.columns)}: ").strip()
    if field not in df.columns:
        print("❌ Invalid column name.")
        return
    value = input(f"Enter value for {field}: ").strip()
    sliced = df[df[field].astype(str).str.lower() == value.lower()]
    print(f"\n✅ Slice: {field} = {value}")
    display_dataframe(sliced)


def dice_operation(df):
    try:
        n = int(input("How many filters? "))
    except ValueError:
        print("❌ Please enter a valid number.")
        return
    
    conditions = []
    for i in range(n):
        col = input(f"Enter filter column {list(df.columns)}: ").strip()
        if col not in df.columns:
            print("❌ Invalid column.")
            continue
        val = input(f"Enter value for {col}: ").strip()
        conditions.append(df[col].astype(str).str.lower() == val.lower())

    if conditions:
        result = df[np.logical_and.reduce(conditions)]
        print("\n✅ Dice operation result:")
        display_dataframe(result)
    else:
        print("No valid filters applied.")


def rollup_operation(df):
    group_col = input(f"Enter column to group by {list(df.columns)}: ").strip()
    num_col = input(f"Enter numeric column to aggregate {list(df.columns)}: ").strip()

    if group_col not in df.columns or num_col not in df.columns:
        print("❌ Invalid column(s).")
        return

    try:
        df[num_col] = pd.to_numeric(df[num_col], errors='coerce')
    except Exception:
        print(f"❌ Column '{num_col}' must be numeric.")
        return

    grouped = df.groupby(group_col, dropna=False)[num_col].sum().reset_index()
    grouped[num_col] = grouped[num_col].fillna(0).astype(float)
    print(f"\n✅ Roll-Up: Total {num_col} by {group_col}")
    display_dataframe(grouped)


def drilldown_operation(df):
    print("\n✅ Drill-Down: Showing full data")
    display_dataframe(df)


def pivot_operation(df):
    row_field = input(f"Enter row field {list(df.columns)}: ").strip()
    col_field = input(f"Enter column field {list(df.columns)}: ").strip()
    num_field = input(f"Enter numeric field {list(df.columns)}: ").strip()

    if any(f not in df.columns for f in [row_field, col_field, num_field]):
        print("❌ Invalid column(s).")
        return

    try:
        df[num_field] = pd.to_numeric(df[num_field], errors='coerce')
    except Exception:
        print(f"❌ Column '{num_field}' must be numeric.")
        return

    pivot = pd.pivot_table(df, index=row_field, columns=col_field, values=num_field, aggfunc=np.sum, fill_value=0)
    pivot = pivot.reset_index()
    print(f"\n✅ Pivot Table: {row_field} vs {col_field} (sum of {num_field})")
    print(pivot.to_string(index=False))


def main():
    filename = input("Enter CSV file name (with .csv): ").strip()
    df = load_data(filename)
    if df is None or df.empty:
        print("❌ No valid data loaded.")
        return

    while True:
        print("\n* OLAP Menu *")
        print("1. View Original Data")
        print("2. Slice")
        print("3. Dice")
        print("4. Roll-Up")
        print("5. Drill-Down")
        print("6. Pivot")
        print("0. Exit")

        choice = input("Enter your choice: ").strip()

        if choice == '1':
            display_dataframe(df)
        elif choice == '2':
            slice_operation(df)
        elif choice == '3':
            dice_operation(df)
        elif choice == '4':
            rollup_operation(df)
        elif choice == '5':
            drilldown_operation(df)
        elif choice == '6':
            pivot_operation(df)
        elif choice == '0':
            print("👋 Exiting... Bye!")
            break
        else:
            print("❌ Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
