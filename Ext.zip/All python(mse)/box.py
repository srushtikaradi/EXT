import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def five_number_summary_boxplot(input_file, column):
    # Load CSV
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        print(f"❌ Error: {input_file} not found.")
        return

    # Check if column exists
    if column not in df.columns:
        print(f"❌ Error: Column '{column}' not found in dataset.")
        return

    # Check if column is numeric
    if not pd.api.types.is_numeric_dtype(df[column]):
        print(f"❌ Error: Column '{column}' is not numeric. Please choose a numeric column.")
        return

    # Extract selected column and drop missing values
    data = df[column].dropna()

    # Calculate quartiles and IQR
    q1 = np.percentile(data, 25)
    q3 = np.percentile(data, 75)
    iqr = q3 - q1

    # Whiskers (1.5 * IQR rule)
    lower_whisker = max(np.min(data), q1 - 1.5 * iqr)
    upper_whisker = min(np.max(data), q3 + 1.5 * iqr)

    # Identify outliers
    outliers = data[(data < lower_whisker) | (data > upper_whisker)]

    # Prepare summary
    summary = {
        "Min": np.min(data),
        "Q1": q1,
        "Median (Q2)": np.median(data),
        "Q3": q3,
        "Max": np.max(data),
        "IQR": iqr,
        "Lower Whisker": lower_whisker,
        "Upper Whisker": upper_whisker
    }

    # Print summary
    print(f"\n📊 Five-number summary for column '{column}':\n")
    for key, value in summary.items():
        print(f"{key:<18}: {value:.2f}")

    # Print outliers
    if not outliers.empty:
        print("\n🚨 Outliers detected:")
        for idx, val in outliers.items():
            print(f"Row {idx}: {val}")
    else:
        print("\n✅ No outliers detected.")

    # Plot boxplot
    plt.figure(figsize=(6, 6))
    plt.boxplot(data,
                patch_artist=True,
                boxprops=dict(facecolor='lightgreen', color='green'),
                medianprops=dict(color='red', linewidth=2),
                whiskerprops=dict(color='black'),
                capprops=dict(color='black'),
                flierprops=dict(markerfacecolor='red', marker='o', markersize=6))

    # Annotate outlier values on the plot
    for outlier in outliers:
        plt.text(1.05, outlier, f"{outlier:.1f}", color='red', fontsize=8, va='center')

    plt.title(f"Box Plot of {column}")
    plt.ylabel(column)
    plt.xticks([1], [column])
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.show()


# ---- MAIN PROGRAM ----
if __name__ == "__main__":
    input_file = input("Enter input CSV filename (with .csv): ").strip()

    # Preview available columns
    try:
        df_preview = pd.read_csv(input_file)
        print("\nAvailable columns:", list(df_preview.columns))
    except FileNotFoundError:
        print(f"❌ Error: {input_file} not found.")
        exit()

    column = input("Enter column name to generate boxplot: ").strip()
    five_number_summary_boxplot(input_file, column)
