import pandas as pd

def t_d_weight_flexible(input_file):
    # Read CSV file
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        print(f"❌ Error: File '{input_file}' not found.")
        return

    print("\n✅ File loaded successfully!")
    print("Available columns:", list(df.columns))

    # Ask user for column selections
    row_col = input("\nEnter the column name to use as ROW labels: ").strip()
    col_col = input("Enter the column name to use as COLUMN labels: ").strip()
    value_col = input("Enter the NUMERIC column name (values to aggregate): ").strip()

    # Validate inputs
    for col in [row_col, col_col, value_col]:
        if col not in df.columns:
            print(f"❌ Error: Column '{col}' not found in dataset.")
            return

    if not pd.api.types.is_numeric_dtype(df[value_col]):
        print(f"❌ Error: Column '{value_col}' must contain numeric values.")
        return

    # Create pivot table
    pivot = df.pivot_table(index=row_col, columns=col_col, values=value_col, aggfunc="sum", fill_value=0)

    # Add totals
    pivot["Total"] = pivot.sum(axis=1)
    pivot.loc["Total"] = pivot.sum()

    # Prepare data for output
    classes = list(df[col_col].unique())
    rows = []
    grand_total = pivot.loc["Total", "Total"]

    for row_item in pivot.index:
        row = [row_item]
        row_total = pivot.loc[row_item, "Total"]
        t_sum = 0
        d_sum = 0

        for c in classes:
            count = pivot.loc[row_item, c]
            t_weight = (count / row_total * 100) if row_total != 0 else 0
            d_weight = (count / pivot.loc["Total", c] * 100) if pivot.loc["Total", c] != 0 else 0
            row += [count, f"{t_weight:.2f}%", f"{d_weight:.2f}%"]
            t_sum += t_weight
            d_sum += d_weight

        row += [row_total, f"{t_sum:.2f}%", f"{(row_total / grand_total * 100):.2f}%"]
        rows.append(row)

    # Build final table
    col_names = [f"{row_col}\\{col_col}"]
    for c in classes:
        col_names += [f"{c} ({value_col})", f"{c} t-weight", f"{c} d-weight"]
    col_names += ["Total Count", "Row t-weight sum", "Row d-weight"]

    output = pd.DataFrame(rows, columns=col_names)

    # Display result
    print(f"\n✅ T-weight & D-weight Table ({row_col} vs {col_col}) based on '{value_col}':\n")
    print(output.to_string(index=False))


# ---- MAIN PROGRAM ----
if __name__ == "__main__":
    input_file = input("Enter input CSV filename (with .csv): ").strip()
    t_d_weight_flexible(input_file)
