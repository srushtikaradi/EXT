import pandas as pd

def z_score_normalize_display(input_file, column):
    # Load data
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        print(f"❌ Error: File '{input_file}' not found.")
        return

    # Check if column exists
    if column not in df.columns:
        print(f"❌ Error: Column '{column}' not found in the dataset.")
        return

    # Check if column is numeric
    if not pd.api.types.is_numeric_dtype(df[column]):
        print(f"❌ Error: Column '{column}' is not numeric. Please choose a numeric column.")
        return

    # Apply Z-score Normalization
    mean_val = df[column].mean()
    std_val = df[column].std()

    if std_val != 0:  # avoid divide-by-zero
        df[f"{column}_ZScore"] = (df[column] - mean_val) / std_val
    else:
        df[f"{column}_ZScore"] = 0

    # Display results
    print(f"\n✅ Z-Score Normalization applied to column '{column}':\n")
    print(df[[column, f"{column}_ZScore"]])

# ---- MAIN PROGRAM ----
if __name__ == "__main__":
    input_file = input("Enter input CSV filename (with .csv): ").strip()

    # Preview available columns
    try:
        df_preview = pd.read_csv(input_file)
        print("\nAvailable columns:", list(df_preview.columns))
    except FileNotFoundError:
        print(f"❌ Error: File '{input_file}' not found.")
        exit()

    column = input("Enter column name to normalize: ").strip()

    # Apply normalization and display
    z_score_normalize_display(input_file, column)
