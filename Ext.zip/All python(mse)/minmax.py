import pandas as pd

def min_max_normalize_custom_display(input_file, column, new_min, new_max):
    # Load data
    try:
        df = pd.read_csv(input_file)
    except FileNotFoundError:
        print(f"❌ Error: File '{input_file}' not found.")
        return

    # Check if column exists
    if column not in df.columns:
        print(f"❌ Error: Column '{column}' not found in the dataset.")
        return

    # Check if column is numeric
    if not pd.api.types.is_numeric_dtype(df[column]):
        print(f"❌ Error: Column '{column}' is not numeric. Please choose a numeric column.")
        return

    # Apply Min-Max Normalization with custom range
    old_min = df[column].min()
    old_max = df[column].max()

    if old_min == old_max:
        df[f"{column}_Normalized"] = new_min  # all same values
    else:
        df[f"{column}_Normalized"] = ((df[column] - old_min) / (old_max - old_min)) * (new_max - new_min) + new_min

    # Display results
    print(f"\n✅ Min-Max Normalization applied to '{column}' with range ({new_min}, {new_max}):\n")
    print(df[[column, f"{column}_Normalized"]])

# ---- MAIN PROGRAM ----
if __name__ == "__main__":
    input_file = input("Enter input CSV filename (with .csv): ").strip()

    # Load once to show available columns
    try:
        df_preview = pd.read_csv(input_file)
        print("\nAvailable columns:", list(df_preview.columns))
    except FileNotFoundError:
        print(f"❌ Error: File '{input_file}' not found.")
        exit()

    column = input("Enter column name to normalize: ").strip()

    # Get custom range from user
    try:
        new_min = float(input("Enter new minimum value for normalization: "))
        new_max = float(input("Enter new maximum value for normalization: "))
    except ValueError:
        print("❌ Please enter valid numeric values for range.")
        exit()

    # Apply normalization and display
    min_max_normalize_custom_display(input_file, column, new_min, new_max)

