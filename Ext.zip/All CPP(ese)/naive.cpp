#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <iomanip>
#include <algorithm>

using namespace std;

// ===================== CSV READER =====================
struct DataFrame {
    vector<string> headers;
    vector<vector<string>> rows;
};

DataFrame readCSV(const string& filename) {
    DataFrame df;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: File '" << filename << "' not found.\n";
        exit(1);
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        stringstream ss(line);
        string value;
        vector<string> row;
        while (getline(ss, value, ',')) {
            value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
            row.push_back(value);
        }
        if (first) {
            df.headers = row;
            first = false;
        } else {
            if (!row.empty())
                df.rows.push_back(row);
        }
    }
    file.close();
    return df;
}

// ===================== COUNT FUNCTION =====================
int countMatches(const DataFrame& df, int feature_idx, const string& value, int label_idx, const string& class_label) {
    int count = 0;
    for (auto& row : df.rows)
        if (row[feature_idx] == value && row[label_idx] == class_label)
            count++;
    return count;
}

int countLabel(const DataFrame& df, int label_idx, const string& class_label) {
    int count = 0;
    for (auto& row : df.rows)
        if (row[label_idx] == class_label)
            count++;
    return count;
}

// ===================== LIKELIHOOD CALCULATION =====================
double calculateAttributeLikelihood(const string& attribute_value, const DataFrame& df,
                                    int feature_idx, const string& class_label, int label_idx) {
    int class_total = countLabel(df, label_idx, class_label);
    if (class_total == 0)
        return 0.0;
    int attribute_match_count = countMatches(df, feature_idx, attribute_value, label_idx, class_label);
    return static_cast<double>(attribute_match_count) / class_total;
}

double calculateLikelihood(const map<string, string>& new_case, const DataFrame& df,
                           const string& class_label, int label_idx) {
    double likelihood = 1.0;
    for (size_t i = 0; i < df.headers.size() - 1; ++i) {
        string feature = df.headers[i];
        string value = new_case.at(feature);
        likelihood *= calculateAttributeLikelihood(value, df, i, class_label, label_idx);
    }
    return likelihood;
}

// ===================== MAIN PROGRAM =====================
int main() {
    cout << "=== Naive Bayes Classifier ===\n\n";
    string filename;
    cout << "Enter the CSV filename (with .csv): ";
    getline(cin, filename);

    DataFrame df = readCSV(filename);

    cout << "\nFile loaded successfully!\n";
    cout << "Available columns: ";
    for (size_t i = 0; i < df.headers.size(); ++i) {
        cout << df.headers[i];
        if (i < df.headers.size() - 1) cout << ", ";
    }
    cout << "\n";

    int label_idx = df.headers.size() - 1;
    string target_col = df.headers[label_idx];
    vector<string> features(df.headers.begin(), df.headers.end() - 1);

    cout << "\nTarget column detected as: '" << target_col << "'\n";
    cout << "\nEnter values for the new case:\n";
    map<string, string> new_case;
    for (auto& feature : features) {
        cout << feature << ": ";
        string val;
        getline(cin, val);
        new_case[feature] = val;
    }

    // === Calculate priors ===
    map<string, double> priors;
    map<string, int> class_counts;
    int total = df.rows.size();

    for (auto& row : df.rows)
        class_counts[row[label_idx]]++;

    for (auto& kv : class_counts)
        priors[kv.first] = static_cast<double>(kv.second) / total;

    cout << "\nPrior Probabilities:\n";
    for (auto& kv : priors)
        cout << "P(" << kv.first << ") = " << fixed << setprecision(4) << kv.second << "\n";

    // === Calculate likelihoods ===
    cout << "\nLikelihoods for Each Attribute:\n";
    cout << left << setw(15) << "Attribute"
         << setw(20) << ("P(attr|" + df.rows[0][label_idx] + ")")
         << setw(20) << ("P(attr|" + df.rows[1][label_idx] + ")") << "\n";
    cout << string(55, '-') << "\n";

    map<string, double> likelihoods;
    for (auto& kv : priors)
        likelihoods[kv.first] = 1.0;

    vector<string> labels;
    for (auto& kv : priors)
        labels.push_back(kv.first);

    for (size_t i = 0; i < features.size(); ++i) {
        string feature = features[i];
        string value = new_case[feature];

        double l1 = calculateAttributeLikelihood(value, df, i, labels[0], label_idx);
        double l2 = (labels.size() > 1) ? calculateAttributeLikelihood(value, df, i, labels[1], label_idx) : 0.0;

        likelihoods[labels[0]] *= l1;
        if (labels.size() > 1)
            likelihoods[labels[1]] *= l2;

        cout << left << setw(15) << value
             << setw(20) << fixed << setprecision(6) << l1
             << setw(20) << fixed << setprecision(6) << l2 << "\n";
    }

    // === Calculate posterior probabilities ===
    cout << "\nPosterior Probabilities:\n";
    map<string, double> posteriors;
    for (auto& label : labels) {
        double post = priors[label] * calculateLikelihood(new_case, df, label, label_idx);
        posteriors[label] = post;
        cout << "P(" << label << " | New Case) = " << fixed << setprecision(6) << post << "\n";
    }

    // === Classification result ===
    string best_label;
    double best_prob = -1.0;
    for (auto& kv : posteriors) {
        if (kv.second > best_prob) {
            best_prob = kv.second;
            best_label = kv.first;
        }
    }

    cout << "\nClassified as: " << best_label << "\n";

    return 0;
}
