#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <map>

using namespace std;

// ===== Structure for a labeled point =====
struct Point {
    string label;
    vector<double> values;
};

// ===== Euclidean distance =====
double distance(const vector<double>& a, const vector<double>& b) {
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); ++i)
        sum += pow(a[i] - b[i], 2);
    return sqrt(sum);
}

// ===== Compute centroid of a cluster =====
vector<double> centroid(const vector<Point>& cluster) {
    if (cluster.empty()) return {};
    size_t dim = cluster[0].values.size();
    vector<double> c(dim, 0.0);
    for (auto& p : cluster)
        for (size_t i = 0; i < dim; ++i)
            c[i] += p.values[i];
    for (double& v : c)
        v /= cluster.size();
    return c;
}

// ===== Region Query: find neighbors within eps =====
vector<int> region_query(const vector<Point>& points, int idx, double eps) {
    vector<int> neighbors;
    for (int j = 0; j < (int)points.size(); ++j)
        if (distance(points[idx].values, points[j].values) <= eps)
            neighbors.push_back(j);
    return neighbors;
}

// ===== Expand Cluster =====
void expand_cluster(const vector<Point>& points, vector<int>& cluster_ids, int cluster_id,
                    int idx, const vector<int>& neighbors, double eps, int minPts) {
    cluster_ids[idx] = cluster_id;
    vector<int> queue = neighbors;

    while (!queue.empty()) {
        int q_idx = queue.front();
        queue.erase(queue.begin());

        if (cluster_ids[q_idx] == -1)
            cluster_ids[q_idx] = cluster_id;

        if (cluster_ids[q_idx] == 0) {
            cluster_ids[q_idx] = cluster_id;
            vector<int> q_neighbors = region_query(points, q_idx, eps);
            if ((int)q_neighbors.size() >= minPts)
                queue.insert(queue.end(), q_neighbors.begin(), q_neighbors.end());
        }
    }
}

// ===== DBSCAN Main Algorithm =====
pair<vector<vector<Point>>, vector<int>> dbscan(const vector<Point>& points, double eps, int minPts) {
    int n = points.size();
    vector<int> cluster_ids(n, 0);
    int cluster_id = 0;

    for (int i = 0; i < n; ++i) {
        if (cluster_ids[i] != 0) continue;

        vector<int> neighbors = region_query(points, i, eps);
        if ((int)neighbors.size() < minPts)
            cluster_ids[i] = -1;
        else {
            cluster_id++;
            expand_cluster(points, cluster_ids, cluster_id, i, neighbors, eps, minPts);
        }
    }

    map<int, vector<Point>> cluster_map;
    for (int i = 0; i < n; ++i)
        if (cluster_ids[i] > 0)
            cluster_map[cluster_ids[i]].push_back(points[i]);

    vector<vector<Point>> clusters;
    for (auto& kv : cluster_map)
        clusters.push_back(kv.second);

    return make_pair(clusters, cluster_ids);
}

// ===== Compute and Display Distance Matrix =====
void compute_distance_matrix(const vector<Point>& points) {
    int n = points.size();
    cout << "\nDistance Matrix:\n";
    cout << setw(12) << " ";
    for (auto& p : points)
        cout << setw(10) << p.label;
    cout << "\n";

    for (int i = 0; i < n; ++i) {
        cout << setw(10) << left << points[i].label << "  ";
        for (int j = 0; j < n; ++j) {
            double d = distance(points[i].values, points[j].values);
            cout << setw(10) << fixed << setprecision(3) << d;
        }
        cout << "\n";
    }
}

// ===== CSV Reader =====
bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) return false;

    string line;
    bool first = true;
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> tokens;
        string value;
        while (getline(ss, value, ',')) {
            value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
            tokens.push_back(value);
        }

        if (tokens.empty()) continue;
        if (first) {
            headers = tokens;
            first = false;
        } else {
            rows.push_back(tokens);
        }
    }
    return true;
}

// ===== MAIN =====
int main() {
    string filename;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> headers;
    vector<vector<string>> rows;
    if (!readCSV(filename, headers, rows)) {
        cerr << "Error: File '" << filename << "' not found or invalid.\n";
        return 1;
    }

    cout << "\nFile loaded successfully.\nAvailable columns:\n";
    for (size_t i = 0; i < headers.size(); ++i)
        cout << i << ". " << headers[i] << "\n";

    cout << "\nEnter column names to use for clustering (comma-separated): ";
    string col_input;
    getline(cin, col_input);

    vector<string> selected;
    string token;
    stringstream ss(col_input);
    while (getline(ss, token, ',')) {
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        if (find(headers.begin(), headers.end(), token) != headers.end())
            selected.push_back(token);
    }

    if (selected.empty()) {
        cerr << "Error: No valid columns selected.\n";
        return 1;
    }

    vector<int> indices;
    for (auto& col : selected)
        indices.push_back(find(headers.begin(), headers.end(), col) - headers.begin());

    vector<Point> points;
    for (size_t i = 0; i < rows.size(); ++i) {
        vector<double> vals;
        for (int idx : indices) {
            try {
                vals.push_back(stod(rows[i][idx]));
            } catch (...) {
                vals.push_back(0.0);
            }
        }
        points.push_back({"P" + to_string(i + 1), vals});
    }

    compute_distance_matrix(points);

    double eps;
    int minPts;
    cout << "\nEnter epsilon (neighborhood radius): ";
    cin >> eps;
    cout << "Enter minPts (minimum neighbors): ";
    cin >> minPts;

    pair<vector<vector<Point>>, vector<int>> dbscan_result = dbscan(points, eps, minPts);
    vector<vector<Point>> clusters = dbscan_result.first;
    vector<int> cluster_assignments = dbscan_result.second;

    int total_points = points.size();
    cout << "\nResults:\n";
    for (size_t i = 0; i < clusters.size(); ++i) {
        double percent = (double)clusters[i].size() * 100.0 / total_points;
        cout << "Cluster " << i + 1 << ": " << clusters[i].size()
             << " points (" << fixed << setprecision(2) << percent << "%) -> [";
        for (size_t j = 0; j < clusters[i].size(); ++j) {
            cout << clusters[i][j].label;
            if (j < clusters[i].size() - 1) cout << ", ";
        }
        cout << "]\n";
    }

    vector<string> noise_points;
    for (size_t i = 0; i < cluster_assignments.size(); ++i)
        if (cluster_assignments[i] == -1)
            noise_points.push_back(points[i].label);

    if (!noise_points.empty()) {
        double noise_percent = (double)noise_points.size() * 100.0 / total_points;
        cout << "Noise points: " << noise_points.size() << " ("
             << noise_percent << "%) -> [";
        for (size_t i = 0; i < noise_points.size(); ++i) {
            cout << noise_points[i];
            if (i < noise_points.size() - 1) cout << ", ";
        }
        cout << "]\n";
    } else {
        cout << "No noise points detected.\n";
    }

    cout << "\nCentroids:\n";
    for (size_t i = 0; i < clusters.size(); ++i) {
        vector<double> c = centroid(clusters[i]);
        cout << "Centroid " << i + 1 << ": [";
        for (size_t j = 0; j < c.size(); ++j) {
            cout << fixed << setprecision(3) << c[j];
            if (j < c.size() - 1) cout << ", ";
        }
        cout << "]\n";
    }

    return 0;
}
