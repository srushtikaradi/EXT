#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <numeric>

using namespace std;

// ===== Data Structures =====
struct Point {
    string label;
    vector<double> values;
};

// ===== Euclidean Distance =====
double distance(const vector<double>& a, const vector<double>& b) {
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); ++i)
        sum += pow(a[i] - b[i], 2);
    return sqrt(sum);
}

// ===== Compute Centroid =====
vector<double> centroid(const vector<Point>& cluster) {
    size_t dim = cluster[0].values.size();
    vector<double> c(dim, 0.0);
    for (auto& p : cluster)
        for (size_t i = 0; i < dim; ++i)
            c[i] += p.values[i];
    for (double& v : c)
        v /= cluster.size();
    return c;
}

// ===== Linkage Distance =====
double linkage_distance(const vector<Point>& clusterA, const vector<Point>& clusterB, const string& method) {
    vector<double> distances;
    for (auto& a : clusterA)
        for (auto& b : clusterB)
            distances.push_back(distance(a.values, b.values));

    if (method == "single")
        return *min_element(distances.begin(), distances.end());
    else if (method == "complete")
        return *max_element(distances.begin(), distances.end());
    else { // average
        double total = accumulate(distances.begin(), distances.end(), 0.0);
        return total / distances.size();
    }
}

// ===== Print Distance Matrix =====
void print_distance_matrix(const vector<vector<Point>>& clusters, const string& method) {
    int n = clusters.size();
    vector<vector<double>> matrix(n, vector<double>(n, 0.0));
    vector<string> labels;

    for (auto& cluster : clusters) {
        string lbl = "";
        for (size_t i = 0; i < cluster.size(); ++i) {
            lbl += cluster[i].label;
            if (i < cluster.size() - 1) lbl += ",";
        }
        labels.push_back(lbl);
    }

    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            matrix[i][j] = matrix[j][i] = linkage_distance(clusters[i], clusters[j], method);

    int col_width = 14;
    cout << "\n📏 Distance Matrix:\n";
    cout << string(col_width + 2, ' ');
    for (auto& lbl : labels)
        cout << setw(col_width) << lbl << " ";
    cout << "\n";

    for (int i = 0; i < n; ++i) {
        cout << left << setw(col_width) << labels[i] << "  ";
        for (int j = 0; j < n; ++j)
            cout << right << setw(col_width) << fixed << setprecision(3) << matrix[i][j] << " ";
        cout << "\n";
    }
}

// ===== Print Clusters and Centroids =====
void print_clusters(const vector<vector<Point>>& clusters) {
    cout << "\n📊 Current Clusters and Centroids:\n";
    for (size_t i = 0; i < clusters.size(); ++i) {
        cout << "Cluster " << setw(2) << i + 1 << ": "
             << clusters[i].size() << " points [";
        for (size_t j = 0; j < clusters[i].size(); ++j) {
            cout << clusters[i][j].label;
            if (j < clusters[i].size() - 1) cout << ", ";
        }
        cout << "], Centroid = [";

        vector<double> c = centroid(clusters[i]);
        for (size_t d = 0; d < c.size(); ++d) {
            cout << fixed << setprecision(3) << c[d];
            if (d < c.size() - 1) cout << ", ";
        }
        cout << "]\n";
    }
}

// ===== Hierarchical Clustering Algorithm =====
void hierarchical_cluster(vector<Point> points, const string& method) {
    vector<vector<Point>> clusters;
    for (auto& p : points)
        clusters.push_back({p});

    int iteration = 1;

    while (clusters.size() > 1) {
        cout << "\n--- Iteration " << iteration << " ---";
        print_clusters(clusters);
        print_distance_matrix(clusters, method);

        double min_dist = 1e9;
        int mergeA = -1, mergeB = -1;

        for (int i = 0; i < (int)clusters.size(); ++i) {
            for (int j = i + 1; j < (int)clusters.size(); ++j) {
                double d = linkage_distance(clusters[i], clusters[j], method);
                if (d < min_dist) {
                    min_dist = d;
                    mergeA = i;
                    mergeB = j;
                }
            }
        }

        cout << "\n🔗 Merging clusters " << mergeA + 1 << " and " << mergeB + 1
             << " (distance=" << fixed << setprecision(3) << min_dist << ")\n";

        clusters[mergeA].insert(clusters[mergeA].end(),
                                clusters[mergeB].begin(),
                                clusters[mergeB].end());
        clusters.erase(clusters.begin() + mergeB);

        iteration++;
    }

    cout << "\n✅ --- Final Cluster ---\n";
    vector<Point> final_cluster = clusters[0];
    vector<double> final_centroid = centroid(final_cluster);

    cout << "Final Cluster: " << final_cluster.size() << " points [";
    for (size_t i = 0; i < final_cluster.size(); ++i) {
        cout << final_cluster[i].label;
        if (i < final_cluster.size() - 1) cout << ", ";
    }
    cout << "]\nCentroid: [";
    for (size_t i = 0; i < final_centroid.size(); ++i) {
        cout << fixed << setprecision(3) << final_centroid[i];
        if (i < final_centroid.size() - 1) cout << ", ";
    }
    cout << "]\n";
}

// ===== Read CSV =====
bool readCSVFile(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) return false;

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts;
        string token;
        stringstream ss(line);
        while (getline(ss, token, ',')) {
            token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
            parts.push_back(token);
        }
        if (parts.empty()) continue;
        if (first) {
            headers = parts;
            first = false;
        } else {
            rows.push_back(parts);
        }
    }
    return true;
}

// ===== MAIN =====
int main() {
    string filename;
    cout << "Enter the CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSVFile(filename, headers, rows)) {
        cerr << "❌ File '" << filename << "' not found or invalid.\n";
        return 1;
    }

    cout << "\n✅ File loaded successfully!\nAvailable columns:\n";
    for (size_t i = 0; i < headers.size(); ++i)
        cout << i << ". " << headers[i] << "\n";

    string col_input;
    cout << "\nEnter column names to use for clustering (comma-separated): ";
    getline(cin, col_input);

    vector<string> selected;
    string token;
    stringstream ss(col_input);
    while (getline(ss, token, ',')) {
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        if (find(headers.begin(), headers.end(), token) != headers.end())
            selected.push_back(token);
    }

    if (selected.empty()) {
        cerr << "❌ No valid columns selected.\n";
        return 1;
    }

    // Get indices
    vector<int> indices;
    for (auto& c : selected)
        indices.push_back(find(headers.begin(), headers.end(), c) - headers.begin());

    // Prepare points
    vector<Point> points;
    for (size_t i = 0; i < rows.size(); ++i) {
        vector<double> vals;
        for (int idx : indices) {
            try {
                vals.push_back(stod(rows[i][idx]));
            } catch (...) {
                vals.push_back(0.0);
            }
        }
        points.push_back({"P" + to_string(i + 1), vals});
    }

    string method;
    cout << "\nEnter linkage method (single / average / complete): ";
    getline(cin, method);
    transform(method.begin(), method.end(), method.begin(), ::tolower);

    if (method != "single" && method != "average" && method != "complete") {
        cerr << "❌ Invalid linkage method.\n";
        return 1;
    }

    hierarchical_cluster(points, method);
    return 0;
}
