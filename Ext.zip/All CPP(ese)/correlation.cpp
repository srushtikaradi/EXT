#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace std;

// ===== Function to Split a CSV Line =====
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        result.push_back(token);
    }
    return result;
}

// ===== Function to Compute Pearson Correlation =====
double pearsonCorrelation(const vector<double>& x, const vector<double>& y) {
    if (x.size() != y.size() || x.empty()) return 0.0;

    double mean_x = 0.0, mean_y = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        mean_x += x[i];
        mean_y += y[i];
    }
    mean_x /= x.size();
    mean_y /= y.size();

    double num = 0.0, den_x = 0.0, den_y = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        num += (x[i] - mean_x) * (y[i] - mean_y);
        den_x += pow(x[i] - mean_x, 2);
        den_y += pow(y[i] - mean_y, 2);
    }

    double denom = sqrt(den_x * den_y);
    if (denom == 0) return 0.0;
    return num / denom;
}

// ===== Function to Read CSV =====
bool readCSV(const string& filename, vector<string>& items, vector<vector<double>>& data) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool firstLine = true;
    vector<string> headers;

    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (parts.empty()) continue;

        if (firstLine) {
            headers = parts; // first row (header)
            firstLine = false;
            continue;
        }

        items.push_back(parts[0]); // first column = activity/item name

        vector<double> row;
        for (size_t i = 1; i < parts.size(); ++i) {
            try {
                row.push_back(stod(parts[i]));
            } catch (...) {
                row.push_back(0.0);
            }
        }
        data.push_back(row);
    }

    return !items.empty() && !data.empty();
}

// ===== Function to Interpret Correlation =====
string interpretCorrelation(double r) {
    if (isnan(r) || fabs(r) < 1e-9)
        return "No correlation";
    else if (fabs(r - 1.0) < 1e-6)
        return "Perfect positive correlation";
    else if (fabs(r + 1.0) < 1e-6)
        return "Perfect negative correlation";
    else if (r > 0)
        return "Positive correlation";
    else
        return "Negative correlation";
}

// ===== MAIN =====
int main() {
    string filename;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> items;
    vector<vector<double>> data;

    if (!readCSV(filename, items, data)) {
        cout << "❌ Could not read file or invalid format.\n";
        return 1;
    }

    int n = items.size();
    if (n < 2) {
        cout << "❌ Not enough rows for correlation calculation.\n";
        return 1;
    }

    cout << "\n✅ File loaded successfully!\n";
    cout << "📋 Total activities found: " << n << "\n";
    cout << "📈 Total pairs to calculate: " << n * (n - 1) / 2 << "\n\n";

    cout << left << setw(20) << "Item 1 (Activity)"
         << setw(20) << "Item 2 (Activity)"
         << setw(35) << "Pearson Correlation Coefficient"
         << "Type of Correlation\n";
    cout << string(95, '-') << "\n";

    cout << fixed << setprecision(3);

    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            double r = pearsonCorrelation(data[i], data[j]);
            string interpretation = interpretCorrelation(r);

            cout << left << setw(20) << items[i]
                 << setw(20) << items[j]
                 << setw(35) << r
                 << interpretation << "\n";
        }
    }

    return 0;
}
