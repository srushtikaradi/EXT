#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace std;

// ===== Split CSV line into values =====
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        // Trim spaces
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        result.push_back(token);
    }
    return result;
}

// ===== Read CSV into header + data =====
bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (parts.empty()) continue;
        if (first) {
            headers = parts;
            first = false;
        } else {
            rows.push_back(parts);
        }
    }

    if (headers.empty() || rows.empty()) {
        cerr << "❌ Error: Empty or invalid CSV file.\n";
        return false;
    }

    return true;
}

// ===== Compute Pearson correlation coefficient =====
double pearsonCorrelation(const vector<double>& x, const vector<double>& y) {
    if (x.size() != y.size() || x.empty()) return NAN;

    double mean_x = 0.0, mean_y = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        mean_x += x[i];
        mean_y += y[i];
    }
    mean_x /= x.size();
    mean_y /= y.size();

    double num = 0.0, den_x = 0.0, den_y = 0.0;
    for (size_t i = 0; i < x.size(); ++i) {
        num += (x[i] - mean_x) * (y[i] - mean_y);
        den_x += pow(x[i] - mean_x, 2);
        den_y += pow(y[i] - mean_y, 2);
    }

    double denom = sqrt(den_x * den_y);
    if (denom == 0.0) return NAN;
    return num / denom;
}

// ===== MAIN =====
int main() {
    string filename;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(filename, headers, rows)) return 1;

    cout << "\n✅ File loaded successfully!\n";
    cout << "Available columns: ";
    for (auto& h : headers) cout << h << "  ";
    cout << "\n";

    string x_col, y_col;
    cout << "Enter column name for X: ";
    getline(cin, x_col);
    cout << "Enter column name for Y: ";
    getline(cin, y_col);

    int x_index = find(headers.begin(), headers.end(), x_col) - headers.begin();
    int y_index = find(headers.begin(), headers.end(), y_col) - headers.begin();

    if (x_index >= headers.size() || y_index >= headers.size()) {
        cerr << "❌ Invalid column names.\n";
        return 1;
    }

    // Extract numeric data
    vector<double> x_vals, y_vals;
    for (auto& row : rows) {
        if (x_index < row.size() && y_index < row.size()) {
            try {
                double xv = stod(row[x_index]);
                double yv = stod(row[y_index]);
                x_vals.push_back(xv);
                y_vals.push_back(yv);
            } catch (...) {
                continue;
            }
        }
    }

    if (x_vals.empty() || y_vals.empty()) {
        cerr << "❌ No valid numeric data found in selected columns.\n";
        return 1;
    }

    double r = pearsonCorrelation(x_vals, y_vals);

    cout << fixed << setprecision(4);
    cout << "\n📊 Pearson correlation coefficient (r): " << r << "\n";

    if (isnan(r)) {
        cout << "No correlation (undefined)\n";
    } else if (fabs(r - 1.0) < 1e-6) {
        cout << "Perfect positive correlation\n";
    } else if (fabs(r + 1.0) < 1e-6) {
        cout << "Perfect negative correlation\n";
    } else if (r > 0) {
        cout << "Positive correlation\n";
    } else if (r < 0) {
        cout << "Negative correlation\n";
    } else {
        cout << "No correlation\n";
    }

    return 0;
}
