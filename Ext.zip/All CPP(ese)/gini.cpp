#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <limits>
using namespace std;

// ==== Helper Struct ====
struct DataFrame {
    vector<string> headers;
    vector<vector<string>> rows;
};

// ==== Read CSV ====
DataFrame readCSV(const string& filename) {
    DataFrame df;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: File '" << filename << "' not found.\n";
        exit(1);
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        stringstream ss(line);
        string value;
        vector<string> row;
        while (getline(ss, value, ',')) {
            // Trim spaces
            value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
            row.push_back(value);
        }
        if (first) {
            df.headers = row;
            first = false;
        } else {
            if (!row.empty())
                df.rows.push_back(row);
        }
    }
    file.close();
    return df;
}

// ==== Class count ====
map<string, int> classCounts(const DataFrame& df, int label_index) {
    map<string, int> counts;
    for (auto& row : df.rows)
        counts[row[label_index]]++;
    return counts;
}

// ==== Entropy ====
double entropy(const map<string, int>& counts) {
    double total = 0.0;
    for (auto& kv : counts)
        total += kv.second;
    if (total == 0) return 0.0;
    double result = 0.0;
    for (auto& kv : counts) {
        double p = kv.second / total;
        if (p > 0)
            result -= p * log2(p);
    }
    return result;
}

// ==== Gini Index ====
double giniIndex(const map<string, int>& counts) {
    double total = 0.0;
    for (auto& kv : counts)
        total += kv.second;
    if (total == 0) return 0.0;
    double sum = 0.0;
    for (auto& kv : counts) {
        double p = kv.second / total;
        sum += p * p;
    }
    return 1.0 - sum;
}

// ==== Split by categorical ====
map<string, DataFrame> splitCategorical(const DataFrame& df, int feature_index) {
    map<string, DataFrame> splits;
    for (auto& row : df.rows)
        splits[row[feature_index]].headers = df.headers;

    for (auto& row : df.rows)
        splits[row[feature_index]].rows.push_back(row);

    return splits;
}

// ==== Split by numeric (median) ====
map<string, DataFrame> splitNumeric(const DataFrame& df, int feature_index) {
    vector<double> values;
    for (auto& row : df.rows) {
        try {
            values.push_back(stod(row[feature_index]));
        } catch (...) {
            // Skip non-numeric
        }
    }
    if (values.empty()) return {};

    sort(values.begin(), values.end());
    double median = values[values.size() / 2];

    DataFrame left, right;
    left.headers = df.headers;
    right.headers = df.headers;

    for (auto& row : df.rows) {
        double val;
        try {
            val = stod(row[feature_index]);
        } catch (...) {
            continue;
        }
        if (val <= median)
            left.rows.push_back(row);
        else
            right.rows.push_back(row);
    }

    map<string, DataFrame> splits;
    string left_label = "<=" + to_string(median);
    string right_label = ">" + to_string(median);
    splits[left_label] = left;
    splits[right_label] = right;

    return splits;
}

// ==== Check if column is numeric ====
bool isNumericColumn(const DataFrame& df, int col_index) {
    int count = 0, numeric = 0;
    for (auto& row : df.rows) {
        if (col_index >= (int)row.size()) continue;
        count++;
        try {
            stod(row[col_index]);
            numeric++;
        } catch (...) {
        }
    }
    return (count > 0 && numeric >= count * 0.8);
}

// ==== Information Gain ====
double infoGain(const DataFrame& df, int feature_index, int label_index) {
    double base_entropy = entropy(classCounts(df, label_index));
    double total_len = df.rows.size();

    map<string, DataFrame> splits;
    if (isNumericColumn(df, feature_index))
        splits = splitNumeric(df, feature_index);
    else
        splits = splitCategorical(df, feature_index);

    double weighted_entropy = 0.0;
    for (auto& kv : splits) {
        double w = (double)kv.second.rows.size() / total_len;
        weighted_entropy += w * entropy(classCounts(kv.second, label_index));
    }
    return base_entropy - weighted_entropy;
}

// ==== Weighted Gini ====
double weightedGini(const DataFrame& df, int feature_index, int label_index) {
    double total_len = df.rows.size();
    map<string, DataFrame> splits;

    if (isNumericColumn(df, feature_index))
        splits = splitNumeric(df, feature_index);
    else
        splits = splitCategorical(df, feature_index);

    double weighted_gini = 0.0;
    for (auto& kv : splits) {
        double w = (double)kv.second.rows.size() / total_len;
        weighted_gini += w * giniIndex(classCounts(kv.second, label_index));
    }
    return weighted_gini;
}

// ==== MAIN ====
int main() {
    string filename;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, filename);

    DataFrame df = readCSV(filename);

    cout << "\nFile loaded successfully.\n";
    cout << "Available columns: ";
    for (size_t i = 0; i < df.headers.size(); ++i) {
        cout << df.headers[i];
        if (i < df.headers.size() - 1) cout << ", ";
    }
    cout << "\n";

    int label_index = df.headers.size() - 1;
    vector<int> feature_indices;
    for (int i = 0; i < label_index; ++i)
        feature_indices.push_back(i);

    cout << "\nTarget column detected as: '" << df.headers[label_index] << "'\n";
    cout << "\nCalculating Information Gain and Gini Index...\n\n";

    struct Result {
        string feature;
        double ig;
        double gini;
    };

    vector<Result> results;
    for (int f : feature_indices) {
        double ig = infoGain(df, f, label_index);
        double g = weightedGini(df, f, label_index);
        results.push_back({df.headers[f], ig, g});
    }

    // Find best features
    double max_ig = -numeric_limits<double>::infinity();
    double min_gini = numeric_limits<double>::infinity();
    string best_ig_feature, best_gini_feature;

    for (auto& r : results) {
        if (r.ig > max_ig) {
            max_ig = r.ig;
            best_ig_feature = r.feature;
        }
        if (r.gini < min_gini) {
            min_gini = r.gini;
            best_gini_feature = r.feature;
        }
    }

    cout << left << setw(20) << "Feature"
         << setw(25) << "Information Gain"
         << setw(15) << "Gini Index" << "\n";
    cout << string(60, '-') << "\n";

    for (auto& r : results) {
        cout << left << setw(20) << r.feature
             << setw(25) << fixed << setprecision(4) << r.ig
             << setw(15) << fixed << setprecision(4) << r.gini << "\n";
    }

    cout << "\nBest Attribute for Splitting:\n";
    cout << "Based on Information Gain (ID3/C4.5): " << best_ig_feature << "\n";
    cout << "Based on Gini Index (CART): " << best_gini_feature << "\n";

    return 0;
}
