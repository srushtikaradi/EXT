#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <iomanip>
#include <cmath>

using namespace std;

// ======== Utility: Split CSV line ========
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        // Trim spaces
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        if (!token.empty())
            result.push_back(token);
    }
    return result;
}

// ======== Read transactions from CSV ========
vector<set<string>> readTransactions(const string& filename) {
    vector<set<string>> transactions;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return {};
    }

    string line;
    vector<string> headers;
    bool first = true;
    bool hasItemsColumn = false;
    int itemsColIndex = -1;

    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (first) {
            headers = parts;
            // Detect "Items" column (case-insensitive)
            for (size_t i = 0; i < headers.size(); ++i) {
                string col = headers[i];
                transform(col.begin(), col.end(), col.begin(), ::tolower);
                if (col == "items") {
                    hasItemsColumn = true;
                    itemsColIndex = static_cast<int>(i);
                    break;
                }
            }
            first = false;
            continue;
        }

        set<string> items;
        if (hasItemsColumn && itemsColIndex >= 0 && itemsColIndex < static_cast<int>(parts.size())) {
            string itemLine = parts[itemsColIndex];
            vector<string> inner = splitCSVLine(itemLine);
            for (auto& i : inner)
                if (!i.empty())
                    items.insert(i);
        } else {
            for (auto& i : parts)
                if (!i.empty())
                    items.insert(i);
        }

        if (!items.empty())
            transactions.push_back(items);
    }

    return transactions;
}

// ======== Generate all k-combinations ========
void generateCombinations(const vector<string>& items, int k, int start, vector<string>& current, vector<set<string>>& result) {
    if (static_cast<int>(current.size()) == k) {
        result.push_back(set<string>(current.begin(), current.end()));
        return;
    }
    for (size_t i = start; i < items.size(); ++i) {
        current.push_back(items[i]);
        generateCombinations(items, k, i + 1, current, result);
        current.pop_back();
    }
}

// ======== Count itemset occurrences ========
map<set<string>, int> getItemsetCounts(const vector<set<string>>& transactions, int k) {
    map<set<string>, int> counts;
    for (auto& trans : transactions) {
        if (static_cast<int>(trans.size()) >= k) {
            vector<string> items(trans.begin(), trans.end());
            vector<set<string>> combos;
            vector<string> current;
            generateCombinations(items, k, 0, current, combos);
            for (auto& c : combos) {
                counts[c]++;
            }
        }
    }
    return counts;
}

// ======== Print frequent itemsets ========
map<set<string>, int> printFrequentItemsets(const map<set<string>, int>& counts, int total, double minSupport) {
    map<set<string>, int> frequent;
    for (auto& entry : counts) {
        double support = static_cast<double>(entry.second) / total;
        if (support >= minSupport) {
            cout << "Item set: { ";
            int i = 0;
            for (auto& item : entry.first) {
                cout << item;
                if (++i < static_cast<int>(entry.first.size())) cout << ", ";
            }
            cout << " } | Support: " << fixed << setprecision(2) << support
                 << " | Count: " << entry.second << "\n";
            frequent[entry.first] = entry.second;
        }
    }
    return frequent;
}

// ======== Generate next-level candidate itemsets ========
map<set<string>, int> generateNextItemsets(const vector<set<string>>& prevFrequent, const vector<set<string>>& transactions, int k) {
    set<set<string>> nextCandidates;
    for (size_t i = 0; i < prevFrequent.size(); ++i) {
        for (size_t j = i + 1; j < prevFrequent.size(); ++j) {
            set<string> uni;
            set_union(prevFrequent[i].begin(), prevFrequent[i].end(),
                      prevFrequent[j].begin(), prevFrequent[j].end(),
                      inserter(uni, uni.begin()));
            if (static_cast<int>(uni.size()) == k)
                nextCandidates.insert(uni);
        }
    }

    map<set<string>, int> counts;
    for (auto& trans : transactions) {
        for (auto& candidate : nextCandidates) {
            if (includes(trans.begin(), trans.end(), candidate.begin(), candidate.end())) {
                counts[candidate]++;
            }
        }
    }
    return counts;
}

// ======== Apriori Algorithm ========
void apriori(const string& filename, double minSupport) {
    vector<set<string>> transactions = readTransactions(filename);
    if (transactions.empty()) {
        cout << "❌ No transactions found or file format invalid.\n";
        return;
    }

    int totalTransactions = static_cast<int>(transactions.size());
    cout << "\n✅ Total Transactions: " << totalTransactions << "\n";

    int k = 1;
    map<set<string>, int> currentCounts = getItemsetCounts(transactions, k);
    map<set<string>, int> allFrequent;

    while (!currentCounts.empty()) {
        cout << "\n" << k << "-itemsets with support ≥ " << minSupport << ":\n";
        map<set<string>, int> frequent = printFrequentItemsets(currentCounts, totalTransactions, minSupport);

        if (frequent.empty()) break;

        for (auto& entry : frequent)
            allFrequent[entry.first] = entry.second;

        vector<set<string>> prevList;
        for (auto& entry : frequent)
            prevList.push_back(entry.first);

        k++;
        currentCounts = generateNextItemsets(prevList, transactions, k);
    }

    cout << "\n✅ Apriori Mining Completed.\n";
    cout << "Total Frequent Itemsets Found: " << allFrequent.size() << "\n";
}

// ======== MAIN ========
int main() {
    string csvFile;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, csvFile);

    double minSupport;
    cout << "Enter minimum support (e.g., 0.3): ";
    cin >> minSupport;

    apriori(csvFile, minSupport);
    return 0;
}
