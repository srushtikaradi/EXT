#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace std;

// === Point Structure ===
struct Point {
    string label;
    double value;
};

// === Compute distance between two scalar values ===
double distance(double a, double b) {
    return fabs(a - b);
}

// === Compute centroid of a cluster ===
double centroid(const vector<Point>& cluster) {
    double sum = 0.0;
    for (auto& p : cluster)
        sum += p.value;
    return sum / cluster.size();
}

// === Compute linkage distance between two clusters ===
double linkage_distance(const vector<Point>& clusterA, const vector<Point>& clusterB, const string& method) {
    vector<double> distances;
    for (auto& a : clusterA)
        for (auto& b : clusterB)
            distances.push_back(distance(a.value, b.value));

    if (method == "single")
        return *min_element(distances.begin(), distances.end());
    else if (method == "complete")
        return *max_element(distances.begin(), distances.end());
    else { // average
        double sum = 0.0;
        for (double d : distances) sum += d;
        return sum / distances.size();
    }
}

// === Print Distance Matrix ===
void print_distance_matrix(const vector<vector<Point>>& clusters, const string& method) {
    int n = clusters.size();
    vector<vector<double>> matrix(n, vector<double>(n, 0.0));
    vector<string> labels;

    for (auto& cluster : clusters) {
        string lbl = "";
        for (size_t i = 0; i < cluster.size(); ++i) {
            lbl += cluster[i].label;
            if (i < cluster.size() - 1) lbl += ",";
        }
        labels.push_back(lbl);
    }

    // Compute distances
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            matrix[i][j] = matrix[j][i] = linkage_distance(clusters[i], clusters[j], method);

    cout << "\n📏 Distance Matrix:\n";
    int col_width = 10;
    cout << string(col_width + 2, ' ');
    for (auto& lbl : labels)
        cout << setw(col_width) << lbl << " ";
    cout << "\n";

    for (int i = 0; i < n; ++i) {
        cout << left << setw(col_width) << labels[i] << "  ";
        for (int j = 0; j < n; ++j)
            cout << right << setw(col_width) << fixed << setprecision(3) << matrix[i][j] << " ";
        cout << "\n";
    }
}

// === Print Current Clusters and Centroids ===
void print_clusters(const vector<vector<Point>>& clusters) {
    cout << "\n📊 Current Clusters and Centroids:\n";
    for (size_t i = 0; i < clusters.size(); ++i) {
        cout << "Cluster " << setw(2) << i + 1 << ": "
             << clusters[i].size() << " points [";
        for (size_t j = 0; j < clusters[i].size(); ++j) {
            cout << clusters[i][j].label;
            if (j < clusters[i].size() - 1) cout << ", ";
        }
        cout << "], Centroid = [" << fixed << setprecision(3) << centroid(clusters[i]) << "]\n";
    }
}

// === Hierarchical Clustering Algorithm ===
void hierarchical_cluster(vector<Point> points, const string& method) {
    vector<vector<Point>> clusters;
    for (auto& p : points)
        clusters.push_back({p});

    int iteration = 1;

    while (clusters.size() > 1) {
        cout << "\n--- Iteration " << iteration << " ---";
        print_clusters(clusters);
        print_distance_matrix(clusters, method);

        double min_dist = 1e9;
        int mergeA = -1, mergeB = -1;

        for (int i = 0; i < (int)clusters.size(); ++i) {
            for (int j = i + 1; j < (int)clusters.size(); ++j) {
                double d = linkage_distance(clusters[i], clusters[j], method);
                if (d < min_dist) {
                    min_dist = d;
                    mergeA = i;
                    mergeB = j;
                }
            }
        }

        cout << "\n🔗 Merging clusters " << mergeA + 1 << " and " << mergeB + 1
             << " (distance=" << fixed << setprecision(3) << min_dist << ")\n";

        clusters[mergeA].insert(clusters[mergeA].end(),
                                clusters[mergeB].begin(),
                                clusters[mergeB].end());
        clusters.erase(clusters.begin() + mergeB);

        iteration++;
    }

    cout << "\n✅ --- Final Cluster ---\n";
    vector<Point> final_cluster = clusters[0];
    double final_centroid = centroid(final_cluster);

    cout << "Final Cluster: " << final_cluster.size() << " points [";
    for (size_t i = 0; i < final_cluster.size(); ++i) {
        cout << final_cluster[i].label;
        if (i < final_cluster.size() - 1) cout << ", ";
    }
    cout << "]\nCentroid: [" << fixed << setprecision(3) << final_centroid << "]\n";
}

// === Read CSV ===
bool readCSVFile(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) return false;

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts;
        string token;
        stringstream ss(line);
        while (getline(ss, token, ',')) {
            token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
            parts.push_back(token);
        }

        if (parts.empty()) continue;
        if (first) {
            headers = parts;
            first = false;
        } else {
            rows.push_back(parts);
        }
    }

    return true;
}

// === MAIN ===
int main() {
    string filename;
    cout << "Enter the CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSVFile(filename, headers, rows)) {
        cerr << "❌ File '" << filename << "' not found or invalid.\n";
        return 1;
    }

    cout << "\n✅ File loaded successfully!\nAvailable columns:\n";
    for (auto& col : headers)
        cout << "- " << col << "\n";

    string col_name;
    cout << "\nEnter the column name for clustering: ";
    getline(cin, col_name);

    int col_idx = find(headers.begin(), headers.end(), col_name) - headers.begin();
    if (col_idx >= (int)headers.size()) {
        cerr << "❌ Invalid column name.\n";
        return 1;
    }

    vector<Point> points;
    for (size_t i = 0; i < rows.size(); ++i) {
        try {
            double val = stod(rows[i][col_idx]);
            points.push_back({"P" + to_string(i + 1), val});
        } catch (...) {
            continue;
        }
    }

    if (points.empty()) {
        cerr << "❌ No valid numeric data found in selected column.\n";
        return 1;
    }

    string method;
    cout << "\nEnter linkage method (single / average / complete): ";
    getline(cin, method);
    transform(method.begin(), method.end(), method.begin(), ::tolower);

    if (method != "single" && method != "average" && method != "complete") {
        cerr << "❌ Invalid linkage method.\n";
        return 1;
    }

    hierarchical_cluster(points, method);
    return 0;
}
