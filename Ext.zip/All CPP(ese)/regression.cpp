#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <iomanip>
#include <cmath>
#include <algorithm>

using namespace std;

// ===== CSV Reader =====
struct DataFrame {
    vector<string> headers;
    vector<vector<string>> rows;
};

DataFrame readCSV(const string& filename) {
    DataFrame df;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: File '" << filename << "' not found.\n";
        exit(1);
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        stringstream ss(line);
        string value;
        vector<string> row;
        while (getline(ss, value, ',')) {
            value.erase(remove_if(value.begin(), value.end(), ::isspace), value.end());
            row.push_back(value);
        }
        if (first) {
            df.headers = row;
            first = false;
        } else if (!row.empty()) {
            df.rows.push_back(row);
        }
    }
    file.close();
    return df;
}

// ===== Helper: Convert column to numeric vector =====
vector<double> getNumericColumn(const DataFrame& df, const string& col_name) {
    vector<double> values;
    int col_index = -1;
    for (size_t i = 0; i < df.headers.size(); ++i)
        if (df.headers[i] == col_name)
            col_index = i;

    if (col_index == -1) {
        cerr << "Invalid column name: " << col_name << endl;
        exit(1);
    }

    for (auto& row : df.rows) {
        if (col_index < (int)row.size()) {
            try {
                double val = stod(row[col_index]);
                values.push_back(val);
            } catch (...) {
                // skip non-numeric or missing values
            }
        }
    }
    return values;
}

// ===== Main =====
int main() {
    string filename;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, filename);

    DataFrame df = readCSV(filename);

    cout << "\nFile loaded successfully!\n";
    cout << "Available columns:\n";
    for (size_t i = 0; i < df.headers.size(); ++i)
        cout << i << ". " << df.headers[i] << "\n";

    string x_col, y_col;
    cout << "\nEnter column name for X: ";
    getline(cin, x_col);
    cout << "Enter column name for Y: ";
    getline(cin, y_col);

    vector<double> x = getNumericColumn(df, x_col);
    vector<double> y = getNumericColumn(df, y_col);

    size_t n = min(x.size(), y.size());
    if (n == 0) {
        cerr << "No valid numeric data found.\n";
        return 1;
    }

    double sum_x = 0, sum_y = 0, sum_xy = 0, sum_x2 = 0;
    for (size_t i = 0; i < n; ++i) {
        sum_x += x[i];
        sum_y += y[i];
        sum_xy += x[i] * y[i];
        sum_x2 += x[i] * x[i];
    }

    double denominator = (n * sum_x2) - (sum_x * sum_x);
    if (denominator == 0) {
        cerr << "Cannot compute regression — denominator is zero.\n";
        return 1;
    }

    double b = ((n * sum_xy) - (sum_x * sum_y)) / denominator;
    double a = ((sum_y * sum_x2) - (sum_x * sum_xy)) / denominator;

    cout << "\nLinear Regression Results:\n";

    cout << fixed << setprecision(3);
    if (a >= 0)
        cout << "Equation: Y = " << b << "X + " << a << "\n";
    else
        cout << "Equation: Y = " << b << "X - " << fabs(a) << "\n";

    cout << "Intercept (c): " << a << "\n";
    cout << "Slope (m): " << b << "\n";

    return 0;
}
