#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace std;

// ===== Split CSV line =====
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        result.push_back(token);
    }
    return result;
}

// ===== Read CSV file =====
bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (parts.empty()) continue;
        if (first) {
            headers = parts;
            first = false;
        } else {
            rows.push_back(parts);
        }
    }

    if (headers.empty() || rows.empty()) {
        cerr << "❌ Error: Empty or invalid CSV file.\n";
        return false;
    }

    return true;
}

// ===== Extract numeric columns =====
vector<pair<double, double>> getNumericColumns(const vector<vector<string>>& rows, int x_idx, int y_idx) {
    vector<pair<double, double>> points;
    for (auto& row : rows) {
        if (x_idx < (int)row.size() && y_idx < (int)row.size()) {
            try {
                double x = stod(row[x_idx]);
                double y = stod(row[y_idx]);
                points.push_back({x, y});
            } catch (...) {
                continue;
            }
        }
    }
    return points;
}

// ===== Compute Euclidean distance =====
double distance2D(double x1, double y1, double x2, double y2) {
    return sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
}

// ===== K-Means algorithm =====
void kMeans2D(vector<pair<double, double>>& data, vector<pair<double, double>>& centroids, int k) {
    const int maxIterations = 100;
    const double tolerance = 1e-4;
    int iterations = 0;
    vector<int> assignments(data.size(), 0);

    while (true) {
        iterations++;

        // Step 1: Assign each point to nearest centroid
        for (size_t i = 0; i < data.size(); ++i) {
            double minDist = distance2D(data[i].first, data[i].second, centroids[0].first, centroids[0].second);
            int cluster = 0;
            for (int c = 1; c < k; ++c) {
                double dist = distance2D(data[i].first, data[i].second, centroids[c].first, centroids[c].second);
                if (dist < minDist) {
                    minDist = dist;
                    cluster = c;
                }
            }
            assignments[i] = cluster;
        }

        // Step 2: Recalculate centroids
        vector<pair<double, double>> newCentroids(k, {0.0, 0.0});
        vector<int> counts(k, 0);

        for (size_t i = 0; i < data.size(); ++i) {
            newCentroids[assignments[i]].first += data[i].first;
            newCentroids[assignments[i]].second += data[i].second;
            counts[assignments[i]]++;
        }

        for (int c = 0; c < k; ++c) {
            if (counts[c] > 0) {
                newCentroids[c].first /= counts[c];
                newCentroids[c].second /= counts[c];
            } else {
                // If a cluster lost all points, retain old centroid
                newCentroids[c] = centroids[c];
            }
        }

        // Display iteration progress
        cout << "\nIteration " << iterations << ":\n";
        for (int c = 0; c < k; ++c) {
            cout << "  Centroid " << c + 1 << ": ("
                 << fixed << setprecision(4)
                 << newCentroids[c].first << ", " << newCentroids[c].second << ")\n";
        }

        // Step 3: Check convergence
        bool converged = true;
        for (int c = 0; c < k; ++c) {
            double shift = distance2D(centroids[c].first, centroids[c].second,
                                      newCentroids[c].first, newCentroids[c].second);
            if (shift >= tolerance) {
                converged = false;
                break;
            }
        }

        centroids = newCentroids;
        if (converged || iterations >= maxIterations)
            break;
    }

    // Step 4: Final output
    cout << "\n✅ Final Cluster Assignments:\n";
    cout << left << setw(10) << "X" << setw(10) << "Y" << setw(10) << "Cluster" << "\n";
    cout << string(30, '-') << "\n";

    for (size_t i = 0; i < data.size(); ++i) {
        cout << fixed << setprecision(4)
             << setw(10) << data[i].first
             << setw(10) << data[i].second
             << setw(10) << (assignments[i] + 1) << "\n";
    }

    cout << "\n📊 Total iterations: " << iterations << "\n";
    cout << "📍 Final Centroids:\n";
    for (int c = 0; c < k; ++c) {
        cout << "  Cluster " << c + 1 << ": ("
             << fixed << setprecision(4)
             << centroids[c].first << ", " << centroids[c].second << ")\n";
    }
}

// ===== MAIN =====
int main() {
    string filename;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(filename, headers, rows))
        return 1;

    cout << "\n✅ File loaded successfully!\n";
    cout << "Available columns:\n";
    for (size_t i = 0; i < headers.size(); ++i)
        cout << i << ". " << headers[i] << "\n";

    string x_col, y_col;
    cout << "\nEnter first column name (X): ";
    getline(cin, x_col);
    cout << "Enter second column name (Y): ";
    getline(cin, y_col);

    int x_idx = find(headers.begin(), headers.end(), x_col) - headers.begin();
    int y_idx = find(headers.begin(), headers.end(), y_col) - headers.begin();

    if (x_idx >= (int)headers.size() || y_idx >= (int)headers.size()) {
        cerr << "❌ Invalid column names.\n";
        return 1;
    }

    vector<pair<double, double>> data = getNumericColumns(rows, x_idx, y_idx);
    if (data.empty()) {
        cerr << "❌ No valid numeric data found in selected columns.\n";
        return 1;
    }

    int k;
    cout << "\nEnter number of clusters (k): ";
    cin >> k;

    vector<pair<double, double>> centroids(k);
    cout << "\nEnter initial centroids (x y):\n";
    for (int i = 0; i < k; ++i) {
        cout << "Centroid " << i + 1 << ": ";
        cin >> centroids[i].first >> centroids[i].second;
    }

    kMeans2D(data, centroids, k);
    return 0;
}
