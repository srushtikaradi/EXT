#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <iomanip>
#include <cmath>

using namespace std;

// ---------- Split CSV Line ----------
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        // Trim spaces
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        if (!token.empty())
            result.push_back(token);
    }
    return result;
}

// ---------- Read Transactions ----------
vector<set<string>> readTransactions(const string& filename) {
    vector<set<string>> transactions;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return {};
    }

    string line;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        set<string> items(parts.begin(), parts.end());
        if (!items.empty())
            transactions.push_back(items);
    }
    return transactions;
}

// ---------- Generate all k-combinations ----------
void generateCombinations(const vector<string>& items, int k, int start, vector<string>& current, vector<set<string>>& result) {
    if ((int)current.size() == k) {
        result.push_back(set<string>(current.begin(), current.end()));
        return;
    }
    for (int i = start; i < (int)items.size(); ++i) {
        current.push_back(items[i]);
        generateCombinations(items, k, i + 1, current, result);
        current.pop_back();
    }
}

// ---------- Count itemsets ----------
map<set<string>, int> getItemsetCounts(const vector<set<string>>& transactions, int size) {
    map<set<string>, int> counts;
    for (const auto& trans : transactions) {
        if ((int)trans.size() >= size) {
            vector<string> items(trans.begin(), trans.end());
            vector<set<string>> combos;
            vector<string> current;
            generateCombinations(items, size, 0, current, combos);
            for (auto& combo : combos)
                counts[combo]++;
        }
    }
    return counts;
}

// ---------- Print Frequent Itemsets ----------
map<set<string>, int> printFrequentItemsets(const map<set<string>, int>& counts, int totalTrans, double minSupport) {
    map<set<string>, int> frequent;
    cout << left << setw(35) << "Itemset" << setw(10) << "Count" << setw(12) << "Support (%)" << "\n";
    cout << string(60, '-') << "\n";

    for (auto& entry : counts) {
        double support = (double)entry.second / totalTrans * 100.0;
        if (support >= minSupport * 100.0) {
            frequent[entry.first] = entry.second;

            string items = "";
            int i = 0;
            for (auto& item : entry.first) {
                items += item;
                if (++i < (int)entry.first.size()) items += ", ";
            }

            cout << "{ " << items << " }";
            cout << string(max(1, 35 - (int)items.size() - 3), ' ')
                 << setw(10) << entry.second
                 << fixed << setprecision(2) << support << "\n";
        }
    }
    return frequent;
}

// ---------- Check if all subsets are frequent ----------
bool allSubsetsFrequent(const set<string>& combination, const map<set<string>, int>& prevItemsets) {
    for (auto& item : combination) {
        set<string> subset = combination;
        subset.erase(item);
        if (prevItemsets.find(subset) == prevItemsets.end())
            return false;
    }
    return true;
}

// ---------- Generate Next Itemsets ----------
map<set<string>, int> generateNextItemsets(const map<set<string>, int>& prevItemsets, const vector<set<string>>& transactions, int size) {
    vector<set<string>> prevList;
    for (auto& entry : prevItemsets)
        prevList.push_back(entry.first);

    set<set<string>> nextCandidates;
    for (size_t i = 0; i < prevList.size(); ++i) {
        for (size_t j = i + 1; j < prevList.size(); ++j) {
            set<string> uni;
            set_union(prevList[i].begin(), prevList[i].end(),
                      prevList[j].begin(), prevList[j].end(),
                      inserter(uni, uni.begin()));
            if ((int)uni.size() == size && allSubsetsFrequent(uni, prevItemsets))
                nextCandidates.insert(uni);
        }
    }

    map<set<string>, int> counts;
    for (const auto& trans : transactions) {
        for (const auto& candidate : nextCandidates)
            if (includes(trans.begin(), trans.end(), candidate.begin(), candidate.end()))
                counts[candidate]++;
    }
    return counts;
}

// ---------- Generate Association Rules ----------
void findAssociationRules(const map<set<string>, int>& frequentItemsets, double minConfidence) {
    cout << "\nASSOCIATION RULES (Confidence ≥ " << (minConfidence * 100) << "%)\n";
    cout << string(70, '=') << "\n";
    cout << left << setw(45) << "Rule" << setw(15) << "Confidence (%)" << "\n";
    cout << string(70, '-') << "\n";

    for (auto& itemset : frequentItemsets) {
        const set<string>& items = itemset.first;
        int itemsetCount = itemset.second;

        if (items.size() > 1) {
            vector<string> elements(items.begin(), items.end());
            int n = elements.size();

            for (int i = 1; i < (1 << n) - 1; ++i) {
                set<string> lhs;
                for (int j = 0; j < n; ++j)
                    if (i & (1 << j))
                        lhs.insert(elements[j]);

                set<string> rhs;
                set_difference(items.begin(), items.end(),
                               lhs.begin(), lhs.end(),
                               inserter(rhs, rhs.begin()));

                auto it = frequentItemsets.find(lhs);
                if (it != frequentItemsets.end() && it->second > 0) {
                    double confidence = (double)itemsetCount / it->second * 100.0;
                    if (confidence >= minConfidence * 100.0) {
                        string lhsStr, rhsStr;
                        for (auto& l : lhs) lhsStr += l + ", ";
                        for (auto& r : rhs) rhsStr += r + ", ";
                        if (!lhsStr.empty()) lhsStr.erase(lhsStr.size() - 2);
                        if (!rhsStr.empty()) rhsStr.erase(rhsStr.size() - 2);

                        cout << "{ " << lhsStr << " } -> { " << rhsStr << " }";
                        cout << string(max(1, 45 - (int)(lhsStr.size() + rhsStr.size() + 7)), ' ')
                             << fixed << setprecision(2) << confidence << "\n";
                    }
                }
            }
        }
    }
}

// ---------- Apriori Main ----------
void apriori(const string& filename, double minSupport, double minConfidence) {
    vector<set<string>> transactions = readTransactions(filename);
    if (transactions.empty()) {
        cout << "❌ No valid transactions found.\n";
        return;
    }

    int totalTrans = transactions.size();
    cout << "\n✅ Total Transactions: " << totalTrans << "\n";

    int k = 1;
    map<set<string>, int> currentCounts = getItemsetCounts(transactions, k);
    map<set<string>, int> allFrequent;

    while (!currentCounts.empty()) {
        cout << "\n" << k << "-ITEMSETS (Support ≥ " << (minSupport * 100) << "%)\n";
        cout << string(60, '=') << "\n";

        map<set<string>, int> frequent = printFrequentItemsets(currentCounts, totalTrans, minSupport);
        if (frequent.empty()) break;

        allFrequent.insert(frequent.begin(), frequent.end());
        currentCounts = generateNextItemsets(frequent, transactions, ++k);
    }

    findAssociationRules(allFrequent, minConfidence);
    cout << "\n--- END OF ANALYSIS ---\n";
}

// ---------- MAIN ----------
int main() {
    string csvFile;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, csvFile);

    double minSupport, minConfidence;
    cout << "Enter Minimum Support (e.g., 0.2): ";
    cin >> minSupport;
    cout << "Enter Minimum Confidence (e.g., 0.6): ";
    cin >> minConfidence;

    apriori(csvFile, minSupport, minConfidence);
    return 0;
}
