#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace std;

// ===== Split CSV line =====
vector<string> splitCSVLine(const string& line) {
    vector<string> result;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) {
        token.erase(remove_if(token.begin(), token.end(), ::isspace), token.end());
        result.push_back(token);
    }
    return result;
}

// ===== Read CSV into header + data =====
bool readCSV(const string& filename, vector<string>& headers, vector<vector<string>>& rows) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "❌ Error: File '" << filename << "' not found.\n";
        return false;
    }

    string line;
    bool first = true;
    while (getline(file, line)) {
        vector<string> parts = splitCSVLine(line);
        if (parts.empty()) continue;
        if (first) {
            headers = parts;
            first = false;
        } else {
            rows.push_back(parts);
        }
    }

    if (headers.empty() || rows.empty()) {
        cerr << "❌ Error: Empty or invalid CSV file.\n";
        return false;
    }

    return true;
}

// ===== Read numeric column =====
vector<double> getNumericColumn(const vector<vector<string>>& rows, int colIndex) {
    vector<double> values;
    for (auto& row : rows) {
        if (colIndex < (int)row.size()) {
            try {
                values.push_back(stod(row[colIndex]));
            } catch (...) {
                continue;
            }
        }
    }
    return values;
}

// ===== K-Means Algorithm =====
void kMeans1D(vector<double>& data, vector<double>& centroids, int k) {
    int maxIterations = 100;
    double tolerance = 1e-4;
    int iterations = 0;
    vector<int> assignments(data.size(), 0);

    while (true) {
        iterations++;

        // Step 1: Assign each data point to the nearest centroid
        for (size_t i = 0; i < data.size(); ++i) {
            double minDist = fabs(data[i] - centroids[0]);
            int cluster = 0;
            for (int c = 1; c < k; ++c) {
                double dist = fabs(data[i] - centroids[c]);
                if (dist < minDist) {
                    minDist = dist;
                    cluster = c;
                }
            }
            assignments[i] = cluster;
        }

        // Step 2: Update centroids
        vector<double> newCentroids(k, 0.0);
        vector<int> counts(k, 0);
        for (size_t i = 0; i < data.size(); ++i) {
            newCentroids[assignments[i]] += data[i];
            counts[assignments[i]]++;
        }
        for (int c = 0; c < k; ++c) {
            if (counts[c] > 0)
                newCentroids[c] /= counts[c];
            else
                newCentroids[c] = centroids[c];
        }

        // Display progress
        cout << "\nIteration " << iterations << ": Centroids = ";
        for (int c = 0; c < k; ++c)
            cout << fixed << setprecision(4) << newCentroids[c] << " ";
        cout << "\n";

        // Step 3: Check convergence
        bool converged = true;
        for (int c = 0; c < k; ++c) {
            if (fabs(newCentroids[c] - centroids[c]) >= tolerance) {
                converged = false;
                break;
            }
        }

        centroids = newCentroids;
        if (converged || iterations >= maxIterations)
            break;
    }

    // Step 4: Display final results
    cout << "\n✅ Final Cluster Assignments:\n";
    cout << left << setw(10) << "Value" << setw(10) << "Cluster" << "\n";
    cout << string(20, '-') << "\n";
    for (size_t i = 0; i < data.size(); ++i) {
        cout << fixed << setprecision(4)
             << setw(10) << data[i]
             << setw(10) << (assignments[i] + 1) << "\n";
    }

    cout << "\n📊 Total iterations: " << iterations << "\n";
    cout << "📍 Final centroids: ";
    for (int c = 0; c < k; ++c)
        cout << fixed << setprecision(4) << centroids[c]
             << (c == k - 1 ? "" : ", ");
    cout << "\n";
}

// ===== MAIN =====
int main() {
    string filename;
    cout << "Enter CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> headers;
    vector<vector<string>> rows;

    if (!readCSV(filename, headers, rows))
        return 1;

    cout << "\n✅ File loaded successfully!\n";
    cout << "Available columns:\n";
    for (size_t i = 0; i < headers.size(); ++i)
        cout << i << ". " << headers[i] << "\n";

    string col_name;
    cout << "\nEnter the column name for clustering: ";
    getline(cin, col_name);

    int colIndex = find(headers.begin(), headers.end(), col_name) - headers.begin();
    if (colIndex >= (int)headers.size()) {
        cerr << "❌ Invalid column name.\n";
        return 1;
    }

    vector<double> data = getNumericColumn(rows, colIndex);
    if (data.empty()) {
        cerr << "❌ No valid numeric data found in selected column.\n";
        return 1;
    }

    int k;
    cout << "\nEnter the number of clusters (k): ";
    cin >> k;

    vector<double> centroids(k);
    cout << "\nEnter initial centroids:\n";
    for (int i = 0; i < k; ++i) {
        cout << "Centroid " << i + 1 << ": ";
        cin >> centroids[i];
    }

    kMeans1D(data, centroids, k);
    return 0;
}
