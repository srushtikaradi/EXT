import pandas as pd

# === Compute linkage distance between two clusters using precomputed matrix ===
def linkage_distance(clusterA, clusterB, df, method):
    distances = []
    for a in clusterA:
        for b in clusterB:
            if a == b:
                continue
            distances.append(df.loc[a, b])

    if method == "single":
        return min(distances)
    elif method == "complete":
        return max(distances)
    else:  # average linkage
        return sum(distances) / len(distances)


# === Nicely formatted distance matrix ===
def print_distance_matrix(clusters, df, method):
    n = len(clusters)
    matrix = [[0.0] * n for _ in range(n)]
    labels = [",".join(cluster) for cluster in clusters]

    # Compute inter-cluster distances
    for i in range(n):
        for j in range(i + 1, n):
            d = linkage_distance(clusters[i], clusters[j], df, method)
            matrix[i][j] = d
            matrix[j][i] = d

    # Print header
    print("\n📏 Distance Matrix:")
    col_width = 10
    print(" " * (col_width + 2), end="")
    for lbl in labels:
        print(f"{lbl:>{col_width}}", end=" ")
    print()

    # Print rows
    for i in range(n):
        print(f"{labels[i]:<{col_width}}", end="  ")
        for j in range(n):
            print(f"{matrix[i][j]:>{col_width}.3f}", end=" ")
        print()


# === Compute centroid of a cluster based on average of all pairwise distances ===
def centroid(cluster, df):
    if len(cluster) == 1:
        return 0.0  # Single element cluster
    total = 0
    count = 0
    for i in range(len(cluster)):
        for j in range(i + 1, len(cluster)):
            total += df.loc[cluster[i], cluster[j]]
            count += 1
    return total / count if count else 0.0


# === Print clusters and centroids ===
def print_clusters(clusters, df):
    print("\n📊 Current Clusters and Centroids:")
    for i, cluster in enumerate(clusters, start=1):
        c = centroid(cluster, df)
        print(f"Cluster {i:2}: {len(cluster)} points {cluster}, Centroid = [{c:.3f}]")


# === Main hierarchical clustering algorithm ===
def hierarchical_cluster(df, method):
    clusters = [[lbl] for lbl in df.columns]
    iteration = 1

    while len(clusters) > 1:
        print(f"\n--- Iteration {iteration} ---")
        print_clusters(clusters, df)
        print_distance_matrix(clusters, df, method)

        # Find the two closest clusters
        min_dist = float("inf")
        mergeA, mergeB = -1, -1
        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):
                d = linkage_distance(clusters[i], clusters[j], df, method)
                if d < min_dist:
                    min_dist = d
                    mergeA, mergeB = i, j

        print(f"\n🔗 Merging clusters {mergeA+1} and {mergeB+1} (distance={min_dist:.3f})")

        # Merge the clusters
        clusters[mergeA].extend(clusters[mergeB])
        clusters.pop(mergeB)

        iteration += 1

    # Final output
    print("\n✅ --- Final Cluster ---")
    final_cluster = clusters[0]
    final_centroid = centroid(final_cluster, df)
    print(f"Final Cluster: {len(final_cluster)} points {final_cluster}")
    print(f"Centroid: [{final_centroid:.3f}]")


# === Main Program ===
def main():
    filename = input("Enter the CSV filename (with .csv): ").strip()

    try:
        df = pd.read_csv(filename, index_col=0)
    except FileNotFoundError:
        print(f"❌ File '{filename}' not found.")
        return
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        return

    print("\n✅ File loaded successfully!")
    print("\n📋 Distance Matrix:")
    print(df)

    # Validate matrix
    if df.shape[0] != df.shape[1]:
        print("❌ Error: Distance matrix must be square (same rows and columns).")
        return
    if not (df.columns.equals(df.index)):
        print("❌ Error: Row and column labels must match exactly.")
        return

    # Choose linkage method
    method = input("\nEnter linkage method (single / average / complete): ").strip().lower()
    if method not in ["single", "average", "complete"]:
        print("❌ Invalid linkage method.")
        return

    hierarchical_cluster(df, method)


if __name__ == "__main__":
    main()
