#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <map>
using namespace std;

// === Read CSV distance matrix ===
bool read_csv(string filename, vector<string> &labels, vector<vector<double>> &distMatrix) {
    ifstream file(filename);
    if (!file.is_open()) return false;

    string line;
    getline(file, line);
    stringstream ss(line);
    string item;
    getline(ss, item, ','); // skip first empty cell
    while (getline(ss, item, ',')) labels.push_back(item);

    int n = labels.size();
    distMatrix.assign(n, vector<double>(n, 0.0));

    int row = 0;
    while (getline(file, line)) {
        stringstream s(line);
        string lbl;
        getline(s, lbl, ','); // row label (A, B, C, etc.)
        for (int col = 0; col < n; col++) {
            getline(s, item, ',');
            distMatrix[row][col] = stod(item);
        }
        row++;
    }

    file.close();
    return true;
}

// === Compute linkage distance between clusters ===
double linkage_distance(const vector<string> &clusterA,
                        const vector<string> &clusterB,
                        const vector<string> &labels,
                        const vector<vector<double>> &distMatrix,
                        const string &method) {
    vector<double> distances;
    for (auto &a : clusterA) {
        for (auto &b : clusterB) {
            if (a == b) continue;
            int i = find(labels.begin(), labels.end(), a) - labels.begin();
            int j = find(labels.begin(), labels.end(), b) - labels.begin();
            distances.push_back(distMatrix[i][j]);
        }
    }

    if (method == "single") return *min_element(distances.begin(), distances.end());
    else if (method == "complete") return *max_element(distances.begin(), distances.end());
    else { // average
        double sum = 0;
        for (auto d : distances) sum += d;
        return sum / distances.size();
    }
}

// === Compute centroid (mean of all pairwise distances inside cluster) ===
double centroid(const vector<string> &cluster,
                const vector<string> &labels,
                const vector<vector<double>> &distMatrix) {
    if (cluster.size() == 1) return 0.0;
    double total = 0.0;
    int count = 0;
    for (int i = 0; i < cluster.size(); ++i) {
        for (int j = i + 1; j < cluster.size(); ++j) {
            int a = find(labels.begin(), labels.end(), cluster[i]) - labels.begin();
            int b = find(labels.begin(), labels.end(), cluster[j]) - labels.begin();
            total += distMatrix[a][b];
            count++;
        }
    }
    return (count > 0) ? total / count : 0.0;
}

// === Print current clusters and centroids ===
void print_clusters(const vector<vector<string>> &clusters,
                    const vector<string> &labels,
                    const vector<vector<double>> &distMatrix) {
    cout << "\n📊 Current Clusters and Centroids:\n";
    for (int i = 0; i < clusters.size(); ++i) {
        double c = centroid(clusters[i], labels, distMatrix);
        cout << "Cluster " << setw(2) << i + 1 << ": { ";
        for (auto &x : clusters[i]) cout << x << " ";
        cout << "}  Centroid = [" << fixed << setprecision(3) << c << "]\n";
    }
}

// === Print inter-cluster distance matrix ===
void print_distance_matrix(const vector<vector<string>> &clusters,
                           const vector<string> &labels,
                           const vector<vector<double>> &distMatrix,
                           const string &method) {
    int n = clusters.size();
    vector<vector<double>> matrix(n, vector<double>(n, 0.0));
    vector<string> names;
    for (auto &c : clusters) {
        string name = "";
        for (int i = 0; i < c.size(); ++i) {
            name += c[i];
            if (i != c.size() - 1) name += ",";
        }
        names.push_back(name);
    }

    // Fill matrix
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j) {
            double d = linkage_distance(clusters[i], clusters[j], labels, distMatrix, method);
            matrix[i][j] = matrix[j][i] = d;
        }

    // Print
    cout << "\n📏 Distance Matrix:\n";
    cout << setw(12) << " ";
    for (auto &n : names) cout << setw(10) << n;
    cout << "\n";

    for (int i = 0; i < n; ++i) {
        cout << setw(10) << left << names[i] << " ";
        for (int j = 0; j < n; ++j) {
            cout << setw(10) << right << fixed << setprecision(3) << matrix[i][j];
        }
        cout << "\n";
    }
}

// === Hierarchical clustering algorithm ===
void hierarchical_cluster(vector<string> &labels,
                          vector<vector<double>> &distMatrix,
                          const string &method) {
    vector<vector<string>> clusters;
    for (auto &l : labels) clusters.push_back({l});
    int iteration = 1;

    while (clusters.size() > 1) {
        cout << "\n--- Iteration " << iteration << " ---\n";
        print_clusters(clusters, labels, distMatrix);
        print_distance_matrix(clusters, labels, distMatrix, method);

        double minDist = 1e9;
        int mergeA = -1, mergeB = -1;

        for (int i = 0; i < clusters.size(); ++i) {
            for (int j = i + 1; j < clusters.size(); ++j) {
                double d = linkage_distance(clusters[i], clusters[j], labels, distMatrix, method);
                if (d < minDist) {
                    minDist = d;
                    mergeA = i;
                    mergeB = j;
                }
            }
        }

        cout << "\n🔗 Merging clusters " << mergeA + 1 << " and " << mergeB + 1
             << " (distance=" << fixed << setprecision(3) << minDist << ")\n";

        // Merge
        clusters[mergeA].insert(clusters[mergeA].end(),
                                clusters[mergeB].begin(), clusters[mergeB].end());
        clusters.erase(clusters.begin() + mergeB);
        iteration++;
    }

    cout << "\n✅ --- Final Cluster ---\n";
    double c = centroid(clusters[0], labels, distMatrix);
    cout << "Final Cluster: { ";
    for (auto &x : clusters[0]) cout << x << " ";
    cout << "}\nCentroid: [" << fixed << setprecision(3) << c << "]\n";
}

// === Main program ===
int main() {
    string filename;
    cout << "Enter the CSV filename (with .csv): ";
    getline(cin, filename);

    vector<string> labels;
    vector<vector<double>> distMatrix;

    if (!read_csv(filename, labels, distMatrix)) {
        cout << "❌ Error reading file '" << filename << "'\n";
        return 1;
    }

    cout << "\n✅ File loaded successfully!\n";
    cout << "📋 Distance Matrix:\n";
    cout << setw(8) << " ";
    for (auto &l : labels) cout << setw(8) << l;
    cout << "\n";
    for (int i = 0; i < labels.size(); ++i) {
        cout << setw(8) << labels[i];
        for (int j = 0; j < labels.size(); ++j)
            cout << setw(8) << distMatrix[i][j];
        cout << "\n";
    }

    string method;
    cout << "\nEnter linkage method (single / average / complete): ";
    cin >> method;

    transform(method.begin(), method.end(), method.begin(), ::tolower);
    if (method != "single" && method != "average" && method != "complete") {
        cout << "❌ Invalid linkage method.\n";
        return 1;
    }

    hierarchical_cluster(labels, distMatrix, method);
    return 0;
}
