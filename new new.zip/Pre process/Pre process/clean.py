import csv
import sys
from collections import Counter

def trim(s: str) -> str:
    return s.strip()

def is_numeric(s: str) -> bool:
    if s == "" or s is None:
        return False
    try:
        float(s)
        return True
    except ValueError:
        return False

def get_mode(values):
    # mode of non-empty strings
    non_empty = [v for v in values if v != ""]
    if not non_empty:
        return ""
    counts = Counter(non_empty)
    return counts.most_common(1)[0][0]

def read_csv_trimmed(path: str):
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        rows = list(reader)
    if not rows:
        return [], []

    # Trim headers
    headers = [trim(h) for h in rows[0]]

    # Trim cells and drop fully empty data rows
    data_rows = []
    for raw in rows[1:]:
        row = [trim(x) for x in raw]
        # consider different-length rows; keep as-is for padding later
        if any(cell != "" for cell in row):
            data_rows.append(row)

    return headers, data_rows

def write_csv(path: str, headers, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for r in rows:
            writer.writerow(r)

def main():
    infile = "dirty.csv"
    try:
        headers, rows = read_csv_trimmed(infile)
    except FileNotFoundError:
        print("❌ dirty.csv not found!")
        return

    if not headers:
        print("❌ CSV is empty or invalid.")
        return

    print("✅ Loaded file. Columns:")
    for h in headers:
        print(" -", h)

    # input columns to keep
    cols_input = input("\nEnter columns to keep (comma separated): ").strip()
    if cols_input == "":
        # mimic the C++ double-getline behavior (one more prompt)
        cols_input = input().strip()

    selected_cols = [trim(x) for x in cols_input.split(",") if trim(x) != ""]
    # map selection to indices
    name_to_idx = {name: i for i, name in enumerate(headers)}
    idx = [name_to_idx[c] for c in selected_cols if c in name_to_idx]

    if not idx:
        print("❌ No valid columns selected")
        return

    # filter headers
    new_headers = [headers[i] for i in idx]

    # filter rows, padding short rows with ""
    new_rows = []
    for r in rows:
        filtered = []
        for i in idx:
            filtered.append(r[i] if i < len(r) else "")
        new_rows.append(filtered)

    print("\n✅ Selected Columns:")
    print("  " + "  ".join(new_headers))
    print("\n🛠 Cleaning data...")

    cols = len(new_headers)

    # ----- Fill Missing Values -----
    for c in range(cols):
        nums = []
        non_numeric_seen = False
        texts = []  # will collect non-numeric (including empty) to mirror C++ behavior

        for r in new_rows:
            val = r[c]
            if is_numeric(val):
                nums.append(float(val))
            else:
                texts.append(val)
                if val != "":  # a truly non-numeric non-empty
                    non_numeric_seen = True

        # Mirror C++ logic:
        # numeric column ONLY if there are numeric values and NO non-numeric values at all
        # (note: C++ pushes empty strings into texts too, so texts.empty() == True
        # only when there were no empties and no non-numeric strings)
        is_pure_numeric = (len(nums) > 0) and (len(texts) == 0)

        if is_pure_numeric:
            mean = sum(nums) / len(nums)
            mean_str = str(mean)  # similar to to_string() in C++
            for r in new_rows:
                if r[c] == "" or not is_numeric(r[c]):
                    r[c] = mean_str
        else:
            mode = get_mode(texts)
            if mode == "":
                mode = "Unknown"
            for r in new_rows:
                if r[c] == "":
                    r[c] = mode

    # ----- Save clean CSV -----
    outfile = "clean1.csv"
    write_csv(outfile, new_headers, new_rows)

    print("\n✅ Cleaning Done!")
    print("📁 Clean file saved as:", outfile)

if __name__ == "__main__":
    # Keep output flush similar to C++ console experience
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(1)
