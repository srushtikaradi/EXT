#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <cstdlib>

using namespace std;

// Trim spaces
string trimStr(string s) {
    s.erase(s.begin(), find_if(s.begin(), s.end(), [](unsigned char c) { return !isspace(c); }));
    s.erase(find_if(s.rbegin(), s.rend(), [](unsigned char c) { return !isspace(c); }).base(), s.end());
    return s;
}

// Split CSV line
vector<string> splitCSV(string line) {
    vector<string> v;
    string x;
    stringstream ss(line);
    while (getline(ss, x, ',')) v.push_back(trimStr(x));
    return v;
}

// Check numeric
bool isNumeric(string s) {
    if (s == "") return false;
    char* end = nullptr;
    strtod(s.c_str(), &end);
    return (*end == '\0');
}

// Get mode (most frequent text)
string getMode(vector<string> arr) {
    unordered_map<string, int> freq;
    for (auto& x : arr) if (!x.empty()) freq[x]++;
    string mode = "";
    int mx = 0;
    for (auto& p : freq) {
        if (p.second > mx) { mx = p.second; mode = p.first; }
    }
    return (mx == 0 ? "" : mode);
}

int main() {
    string file = "dirty.csv";
    ifstream fin(file);

    if (!fin.is_open()) {
        cout << "❌ dirty.csv not found!\n";
        return 0;
    }

    string line;
    getline(fin, line);
    vector<string> headers = splitCSV(line);

    vector<vector<string>> rows;
    while (getline(fin, line)) {
        auto r = splitCSV(line);
        bool empty = true;
        for (auto& x : r) if (!x.empty()) empty = false;
        if (!empty) rows.push_back(r);
    }
    fin.close();

    cout << "✅ Loaded file. Columns:\n";
    for (auto& h : headers) cout << " - " << h << "\n";

    cout << "\nEnter columns to keep (comma separated): ";
    string input;
    getline(cin, input);
    if (input.size() == 0) getline(cin, input); // handle enter key issue

    vector<string> selected = splitCSV(input);
    vector<int> idx;

    for (auto& col : selected) {
        auto it = find(headers.begin(), headers.end(), col);
        if (it != headers.end()) idx.push_back(it - headers.begin());
    }

    if (idx.empty()) {
        cout << "❌ No valid columns selected\n";
        return 0;
    }

    // Filter selected columns
    vector<string> newHeaders;
    for (int i : idx) newHeaders.push_back(headers[i]);

    vector<vector<string>> newRows;
    for (auto& r : rows) {
        vector<string> t;
        for (int i : idx) t.push_back((i < (int)r.size()) ? r[i] : "");
        newRows.push_back(t);
    }

    cout << "\n✅ Selected Columns:\n";
    for (auto& h : newHeaders) cout << h << "  ";
    cout << "\n\n🛠 Cleaning data...\n";

    int cols = newHeaders.size();

    // ----- Fill Missing Values -----
    for (int c = 0; c < cols; c++) {
        bool numeric = true;
        vector<double> nums;
        vector<string> texts;

        for (auto& r : newRows) {
            if (isNumeric(r[c])) nums.push_back(stod(r[c]));
            else texts.push_back(r[c]);
        }

        if (nums.size() > 0 && texts.empty()) { // numeric column
            double sum = 0;
            for (double x : nums) sum += x;
            double mean = sum / nums.size();

            for (auto& r : newRows)
                if (r[c] == "" || !isNumeric(r[c]))
                    r[c] = to_string(mean);

        } else { // text column
            string mode = getMode(texts);
            if (mode == "") mode = "Unknown";
            for (auto& r : newRows)
                if (r[c] == "") r[c] = mode;
        }
    }

    // ----- Save clean CSV -----
    ofstream out("clean.csv");
    for (int i = 0; i < cols; i++) {
        if (i) out << ",";
        out << newHeaders[i];
    }
    out << "\n";

    for (auto& r : newRows) {
        for (int i = 0; i < cols; i++) {
            if (i) out << ",";
            out << r[i];
        }
        out << "\n";
    }
    out.close();

    cout << "\n✅ Cleaning Done!";
    cout << "\n📁 Clean file saved as: clean.csv\n";

    return 0;
}